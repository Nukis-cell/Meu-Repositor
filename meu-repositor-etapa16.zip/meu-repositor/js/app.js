// js/app.js
// Ponto de entrada da aplicação.
//
// Responsável por:
// - registrar o Service Worker;
// - controlar a navegação entre as telas (mostrar/ocultar seções);
// - inicializar cada tela (a partir da Etapa 4, telas passam a ter
//   inicialização própria, ligada ao banco de dados).

import { initProductsPage, refreshProductsPage } from './pages/products.js';
import { initHomePage, renderResumoHome } from './pages/home.js';
import { initReplenishmentPage, renderizarListaReposicao } from './pages/replenishment.js';
import { initExpirationsPage, renderizarListaValidades } from './pages/expirations.js';
import { initSettingsPage } from './pages/settings.js';
import { registrarErro } from './utils/errorlog.js';
import { showToast } from './components/toast.js';

const PAGE_TITLES = {
  home: 'Meu Repositor',
  reposicao: 'Reposição',
  validades: 'Validades',
  produtos: 'Produtos',
  config: 'Configurações',
};

// Ações a rodar sempre que o usuário navega para determinada tela,
// para refletir mudanças feitas em outra tela (ex.: um produto
// marcado para repor na tela Produtos deve aparecer atualizado ao
// abrir a tela Reposição, e vice-versa).
const REFRESH_AO_ENTRAR = {
  home: renderResumoHome,
  produtos: refreshProductsPage,
  reposicao: renderizarListaReposicao,
  validades: renderizarListaValidades,
};

function showPage(target) {
  document.querySelectorAll('.page').forEach((el) => {
    el.classList.toggle('is-hidden', el.dataset.page !== target);
  });

  document.querySelectorAll('.nav-item').forEach((btn) => {
    btn.classList.toggle('is-active', btn.dataset.target === target);
  });

  const titleEl = document.getElementById('app-header-title');
  if (titleEl) {
    titleEl.textContent = PAGE_TITLES[target] || 'Meu Repositor';
  }

  const refresh = REFRESH_AO_ENTRAR[target];
  if (refresh) {
    refresh();
  }
}

// ---------------------------------------------------------------------
// Tratamento global de erros (Etapa 13)
// ---------------------------------------------------------------------
//
// Até aqui, um erro inesperado (bug num handler sem try/catch, uma
// promessa rejeitada sem `catch`, etc.) só aparecia no console do
// navegador — o usuário via a tela travada ou sem reação nenhuma, sem
// entender o que aconteceu. Os dois listeners abaixo capturam
// QUALQUER erro que escape dos tratamentos específicos já existentes
// em cada tela, registram no log de diagnóstico (Configurações →
// Diagnóstico) e avisam o usuário de forma discreta, sem travar o
// app: o erro já aconteceu, mas o app continua utilizável.

// Evita alagar a tela de toasts se vários erros dispararem em
// sequência muito rápida (ex.: um mesmo bug repetindo a cada clique).
let ultimoAvisoDeErroEm = 0;
const INTERVALO_MIN_ENTRE_AVISOS_MS = 4000;

function avisarErroInesperado() {
  const agora = Date.now();
  if (agora - ultimoAvisoDeErroEm < INTERVALO_MIN_ENTRE_AVISOS_MS) {
    return;
  }
  ultimoAvisoDeErroEm = agora;
  showToast('Ocorreu um erro inesperado. Veja Config. → Diagnóstico.', 'error');
}

function initGlobalErrorHandling() {
  // Erros síncronos não capturados (ex.: acessar propriedade de
  // `null`, erro de lógica dentro de um handler de clique).
  window.addEventListener('error', (event) => {
    registrarErro({
      origem: 'window.onerror',
      mensagem: event.message || 'Erro desconhecido.',
      stack: event.error?.stack || '',
      contexto: event.filename ? `${event.filename}:${event.lineno}:${event.colno}` : '',
    });
    avisarErroInesperado();
  });

  // Promises rejeitadas sem `.catch`/`try-catch` — o caso mais comum
  // neste app, já que a maior parte do código é assíncrona
  // (IndexedDB). Vários handlers de clique em js/pages/ chamam
  // funções async sem try/catch próprio; antes desta etapa, um erro
  // ali ficava só no console, sem nenhum feedback para o usuário.
  window.addEventListener('unhandledrejection', (event) => {
    const err = event.reason;
    registrarErro({
      origem: 'promise-rejeitada',
      mensagem: err?.message || String(err),
      stack: err?.stack || '',
    });
    avisarErroInesperado();
  });
}

function initNavigation() {
  document.querySelectorAll('.nav-item').forEach((btn) => {
    btn.addEventListener('click', () => {
      showPage(btn.dataset.target);
    });
  });
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('sw.js')
        .catch((err) => {
          console.error('Falha ao registrar o Service Worker:', err);
          registrarErro({
            origem: 'service-worker',
            mensagem: err?.message || String(err),
            stack: err?.stack || '',
            contexto: 'registro do sw.js',
          });
          // Não mostra toast aqui: sem Service Worker o app ainda
          // funciona normalmente enquanto a aba estiver aberta, só
          // perde o uso offline/instalação — não é um erro que
          // interrompa o que o usuário está fazendo agora.
        });
    });
  }
}

// Etapa 13: cada tela é inicializada dentro do seu próprio try/catch,
// para um bug na inicialização de UMA tela não impedir as outras de
// funcionarem (ex.: se `initExpirationsPage` falhar por algum motivo,
// Produtos e Reposição continuam normais). Antes desta etapa, um erro
// em qualquer uma travava `initPages()` inteiro no meio.
const PAGINAS_PARA_INICIAR = [
  ['home', initHomePage],
  ['produtos', initProductsPage],
  ['reposicao', initReplenishmentPage],
  ['validades', initExpirationsPage],
  ['config', initSettingsPage],
];

function initPages() {
  // Cada tela liga seus próprios eventos e carrega seus dados uma vez;
  // como é uma SPA de uma página só, os elementos já existem no DOM
  // mesmo quando a seção está oculta (`is-hidden`).
  for (const [nome, iniciar] of PAGINAS_PARA_INICIAR) {
    try {
      iniciar();
    } catch (err) {
      console.error(`Falha ao iniciar a tela "${nome}":`, err);
      registrarErro({
        origem: 'init-pagina',
        mensagem: err?.message || String(err),
        stack: err?.stack || '',
        contexto: `tela "${nome}"`,
      });
    }
  }
}

function init() {
  // Registrado primeiro, antes de qualquer outra coisa: se algo mais
  // abaixo (navegação, inicialização de telas) falhar de forma
  // inesperada, o erro ainda é capturado e registrado.
  initGlobalErrorHandling();
  initNavigation();
  initPages();
  registerServiceWorker();
}

document.addEventListener('DOMContentLoaded', init);
