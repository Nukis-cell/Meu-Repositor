// js/utils/validation.js
// Funções utilitárias de validação de entradas do usuário
// (ex.: formato de código de barras, campos obrigatórios).
//
// Nota da Etapa 15 (revisão final): este arquivo ficou vazio de
// propósito ao longo de todo o projeto. As validações que realmente
// surgiram (nome de produto obrigatório, código de barras vazio,
// data de validade obrigatória, conflito de código duplicado, etc.)
// são poucas, específicas de cada entidade e já ficam junto da regra
// de negócio correspondente em `js/db/*` (ex.: `criarProduto` em
// products.js, `associarCodigo` em barcodes.js) — extrair cada uma
// para cá exigiria "adivinhar" uma categorização genérica sem nenhum
// caso real de reuso entre elas. Mantido como esqueleto para o caso
// de uma validação futura ser claramente compartilhada por mais de
// um módulo (ex.: um validador de formato de código de barras usado
// tanto no cadastro manual quanto numa eventual importação em lote).
