// js/utils/storage.js
// Funções utilitárias auxiliares relacionadas a armazenamento fora do
// IndexedDB (localStorage), para dados simples que não precisam de uma
// object store própria — por exemplo, a data do último backup feito
// (Etapa 12). Não é usado para os dados do app em si; isso é sempre
// IndexedDB (ver js/db/).

const PREFIXO = 'meu-repositor:';

/** Lê um valor salvo no localStorage (já parseado de JSON). Retorna null se não existir ou for inválido. */
export function lerStorage(chave) {
  try {
    const bruto = window.localStorage.getItem(PREFIXO + chave);
    return bruto ? JSON.parse(bruto) : null;
  } catch (err) {
    console.warn(`Falha ao ler "${chave}" do localStorage:`, err);
    return null;
  }
}

/** Salva um valor no localStorage (serializado em JSON). Falha silenciosamente (ex.: modo privado sem quota). */
export function salvarStorage(chave, valor) {
  try {
    window.localStorage.setItem(PREFIXO + chave, JSON.stringify(valor));
  } catch (err) {
    console.warn(`Falha ao salvar "${chave}" no localStorage:`, err);
  }
}
