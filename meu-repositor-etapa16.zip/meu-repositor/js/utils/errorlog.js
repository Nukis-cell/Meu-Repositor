// js/utils/errorlog.js
// Registro de erros para a área de Diagnóstico (Etapa 13).
//
// Guardado no localStorage (via js/utils/storage.js), de propósito
// SEPARADO do IndexedDB: se o problema for justamente o IndexedDB
// falhando (banco bloqueado, sem quota, navegação privada em
// navegadores que restringem IndexedDB, etc.), o registro de erro não
// pode depender dele também para funcionar — senão o app ficaria sem
// nenhum jeito de saber o que deu errado justamente no cenário em que
// mais precisaria disso.
//
// Guarda só os erros mais recentes (MAX_ERROS), para não crescer sem
// limite num uso diário prolongado — mesma preocupação já registrada
// como limitação conhecida do Histórico (Etapa 11), só que aqui já
// resolvida desde o início.

import { lerStorage, salvarStorage } from './storage.js';

const CHAVE_ERROS = 'errosDiagnostico';
const MAX_ERROS = 50;

/**
 * Registra um erro no log de diagnóstico.
 * Nunca lança exceção — um problema ao registrar o erro não pode virar
 * um segundo erro por cima do primeiro.
 * @param {{origem: string, mensagem: string, stack?: string, contexto?: string}} dados
 */
export function registrarErro({ origem, mensagem, stack = '', contexto = '' }) {
  try {
    const erros = lerStorage(CHAVE_ERROS) || [];
    erros.unshift({
      origem: String(origem || 'desconhecida'),
      // Corta mensagens/stacks muito longas — é um resumo para
      // diagnóstico, não precisa (nem deve) guardar tudo.
      mensagem: String(mensagem || 'Erro sem mensagem.').slice(0, 500),
      stack: String(stack || '').slice(0, 2000),
      contexto: String(contexto || ''),
      criadoEm: new Date().toISOString(),
    });
    salvarStorage(CHAVE_ERROS, erros.slice(0, MAX_ERROS));
  } catch (err) {
    // Último recurso: se nem isso funcionar, ao menos fica no console.
    console.warn('Falha ao registrar erro de diagnóstico:', err);
  }
}

/** Lista os erros registrados, mais recente primeiro. */
export function listarErros() {
  return lerStorage(CHAVE_ERROS) || [];
}

/** Limpa o histórico de erros de diagnóstico. */
export function limparErros() {
  salvarStorage(CHAVE_ERROS, []);
}
