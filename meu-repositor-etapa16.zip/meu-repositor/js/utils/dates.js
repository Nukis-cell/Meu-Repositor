// js/utils/dates.js
// Funções utilitárias de data: cálculo de dias restantes, classificação
// de validade (crítico/atenção/normal/vencido) e formatação para
// exibição. Implementado na Etapa 8/9.

import { VALIDADE_LIMITES } from '../config/config.js';

/** Retorna a data de hoje "zerada" (00:00), para comparar apenas o dia. */
function hojeZerado() {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  return hoje;
}

/** Converte uma data no formato ISO (YYYY-MM-DD) para um Date local "zerado". */
function paraDataLocal(dataISO) {
  const [ano, mes, dia] = dataISO.split('-').map(Number);
  return new Date(ano, mes - 1, dia);
}

/**
 * Calcula quantos dias faltam até a data de validade.
 * Retorna um número negativo se a data já passou (dias vencido) e 0 se
 * a validade é hoje.
 */
export function calcularDiasRestantes(dataValidadeISO) {
  const validade = paraDataLocal(dataValidadeISO);
  const diffMs = validade - hojeZerado();
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

/**
 * Classifica uma validade em 'vencido' | 'critico' | 'atencao' | 'normal',
 * de acordo com os limites configurados em VALIDADE_LIMITES
 * (js/config/config.js).
 */
export function classificarValidade(dataValidadeISO) {
  const dias = calcularDiasRestantes(dataValidadeISO);
  if (dias < 0) {
    return 'vencido';
  }
  if (dias <= VALIDADE_LIMITES.CRITICO_DIAS) {
    return 'critico';
  }
  if (dias <= VALIDADE_LIMITES.ATENCAO_DIAS) {
    return 'atencao';
  }
  return 'normal';
}

/** Formata uma data ISO (YYYY-MM-DD) para exibição em pt-BR (DD/MM/AAAA). */
export function formatarDataValidade(dataValidadeISO) {
  return paraDataLocal(dataValidadeISO).toLocaleDateString('pt-BR');
}

/** Texto amigável sobre a proximidade/vencimento (ex.: "Vence em 5 dias"). */
export function textoDiasRestantes(dataValidadeISO) {
  const dias = calcularDiasRestantes(dataValidadeISO);
  if (dias < 0) {
    const diasVencido = Math.abs(dias);
    return diasVencido === 1 ? 'Venceu há 1 dia' : `Venceu há ${diasVencido} dias`;
  }
  if (dias === 0) {
    return 'Vence hoje';
  }
  if (dias === 1) {
    return 'Vence amanhã';
  }
  return `Vence em ${dias} dias`;
}
