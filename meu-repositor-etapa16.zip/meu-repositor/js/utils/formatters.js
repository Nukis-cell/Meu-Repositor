// js/utils/formatters.js
// Funções utilitárias de formatação de texto/números para exibição.

/** Escapa texto para inserção segura em innerHTML (evita XSS/HTML quebrado). */
export function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}
