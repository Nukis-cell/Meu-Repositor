// js/pages/replenishment.js
// Tela Reposição: lista de produtos marcados para repor (pendentes),
// histórico de itens já concluídos (Etapa 7) e itens marcados como
// "falta" — não havia o produto no estoque para repor (Ajuste
// pós-Etapa 12, item 4).
//
// A marcação "para repor" em si acontece na tela Produtos (botão
// "📦 Repor" no card do produto) ou no modal de ação rápida da tela
// Início (ao escanear um produto já cadastrado); esta tela apenas
// lista os itens e permite concluir, marcar falta ou reativar.

import {
  listarPendentes,
  listarConcluidos,
  listarFalta,
  concluirReposicao,
  marcarFalta,
  reativarReposicao,
} from '../db/replenishment.js';
import { obterProduto } from '../db/products.js';
import { registrarEvento } from '../db/history.js';
import { abrirDetalhesProduto } from './products.js';
import { showToast } from '../components/toast.js';
import { escapeHTML } from '../utils/formatters.js';

const LISTA_ID = 'reposicao-lista';
const TABS_ID = 'reposicao-tabs';

// Configuração de cada aba: como buscar os itens, qual campo de data
// usar (rótulo + ordenação) e mensagem de lista vazia.
const ABAS = {
  pendentes: {
    listar: listarPendentes,
    campoData: 'criadoEm',
    rotuloData: 'Adicionado em',
    listaVazia: 'Nenhum produto marcado para repor.',
  },
  concluidos: {
    listar: listarConcluidos,
    campoData: 'concluidoEm',
    rotuloData: 'Concluído em',
    listaVazia: 'Nenhuma reposição concluída ainda.',
  },
  falta: {
    listar: listarFalta,
    campoData: 'faltaEm',
    rotuloData: 'Sem estoque em',
    listaVazia: 'Nenhum item marcado como falta no estoque.',
  },
};

let abaAtual = 'pendentes';

function formatarData(iso) {
  if (!iso) {
    return '';
  }
  return new Date(iso).toLocaleDateString('pt-BR');
}

function botoesDeAcaoHTML(aba) {
  if (aba === 'pendentes') {
    return `
      <button type="button" class="btn-icon" data-action="falta" aria-label="Marcar falta no estoque">🚫</button>
      <button type="button" class="btn-icon" data-action="concluir" aria-label="Concluir reposição">✅</button>
    `;
  }
  if (aba === 'falta') {
    return `
      <button type="button" class="btn-icon" data-action="reativar" aria-label="Marcar para repor de novo">🔁</button>
    `;
  }
  return '';
}

function itemHTML(item, produto, aba) {
  const nome = produto ? escapeHTML(produto.nome) : `Produto #${item.produtoId} (removido)`;
  // Ajuste: exibir a marca junto do nome, já que produtos diferentes
  // podem ter o mesmo nome e só mudar a marca (ex.: "Torrada
  // tradicional" Piraquê x Marilan) — sem isso não dá pra diferenciar
  // qual item é qual na lista de reposição.
  const marca = produto ? escapeHTML(produto.marca ?? '') : '';
  const { campoData, rotuloData } = ABAS[aba];
  const dataLabel = `${rotuloData} ${formatarData(item[campoData])}`;

  return `
    <div class="card reposicao-item" data-id="${item.id}" data-produto-id="${item.produtoId}">
      <div class="reposicao-item-info" data-action="detalhes">
        <span class="reposicao-item-nome">${nome}</span>
        ${marca ? `<span class="reposicao-item-marca">${marca}</span>` : ''}
        <span class="reposicao-item-data">${dataLabel}</span>
      </div>
      <div class="reposicao-item-actions">${botoesDeAcaoHTML(aba)}</div>
    </div>
  `;
}

/** Carrega os itens da aba informada já com o produto associado a cada um. */
async function carregarItensComProduto(aba) {
  const { listar, campoData } = ABAS[aba];
  const itens = await listar();
  const comProduto = await Promise.all(
    itens.map(async (item) => ({ item, produto: await obterProduto(item.produtoId) }))
  );
  // Mais recentes primeiro.
  comProduto.sort((a, b) => new Date(b.item[campoData]) - new Date(a.item[campoData]));
  return comProduto;
}

/** Renderiza a lista da aba atualmente selecionada. Exportada para ser chamada ao entrar na tela. */
export async function renderizarListaReposicao() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  const itens = await carregarItensComProduto(abaAtual);

  if (itens.length === 0) {
    listaEl.innerHTML = `<p class="empty-state">${ABAS[abaAtual].listaVazia}</p>`;
    return;
  }

  listaEl.innerHTML = itens
    .map(({ item, produto }) => itemHTML(item, produto, abaAtual))
    .join('');
}

function selecionarAba(aba) {
  abaAtual = aba;

  const tabsEl = document.getElementById(TABS_ID);
  if (tabsEl) {
    tabsEl.querySelectorAll('.segmented-btn').forEach((btn) => {
      btn.classList.toggle('is-active', btn.dataset.tab === aba);
    });
  }

  renderizarListaReposicao();
}

function ligarAbas() {
  const tabsEl = document.getElementById(TABS_ID);
  if (!tabsEl) {
    return;
  }
  tabsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-tab]');
    if (!btn) {
      return;
    }
    selecionarAba(btn.dataset.tab);
  });
}

function ligarEventosDaLista() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  listaEl.addEventListener('click', async (e) => {
    const itemEl = e.target.closest('.reposicao-item');
    if (!itemEl) {
      return;
    }
    const id = Number(itemEl.dataset.id);
    const produtoId = Number(itemEl.dataset.produtoId);
    const btnAcao = e.target.closest('button[data-action]');

    if (btnAcao) {
      const acao = btnAcao.dataset.action;
      const produto = await obterProduto(produtoId);
      const nomeProduto = produto ? produto.nome : `produto #${produtoId}`;

      if (acao === 'concluir') {
        await concluirReposicao(id);
        showToast('Reposição concluída.');
        await registrarEvento({
          tipo: 'reposicao_concluida',
          descricao: `Reposição de "${nomeProduto}" concluída.`,
          produtoId,
        });
        await renderizarListaReposicao();
      } else if (acao === 'falta') {
        await marcarFalta(id);
        showToast('Marcado como falta no estoque.');
        await registrarEvento({
          tipo: 'reposicao_falta',
          descricao: `"${nomeProduto}" marcado como falta no estoque (não foi possível repor).`,
          produtoId,
        });
        await renderizarListaReposicao();
      } else if (acao === 'reativar') {
        await reativarReposicao(id);
        showToast('Marcado para repor de novo.');
        await registrarEvento({
          tipo: 'reposicao_marcada',
          descricao: `"${nomeProduto}" marcado para repor de novo (estoque reposto).`,
          produtoId,
        });
        await renderizarListaReposicao();
      }
      return;
    }

    const areaDetalhes = e.target.closest('[data-action="detalhes"]');
    if (areaDetalhes) {
      const produto = await obterProduto(produtoId);
      if (produto) {
        abrirDetalhesProduto(produto);
      }
    }
  });
}

/** Inicializa a tela de Reposição (chamado uma vez pelo app.js). */
export function initReplenishmentPage() {
  ligarAbas();
  ligarEventosDaLista();
  renderizarListaReposicao();
}
