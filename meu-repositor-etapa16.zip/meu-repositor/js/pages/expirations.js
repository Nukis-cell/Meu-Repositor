// js/pages/expirations.js
// Tela Validades: lista, em um só lugar, todas as validades de todos os
// produtos, ordenadas por urgência (vencido → crítico → atenção →
// normal e, dentro de cada grupo, pela data mais próxima). Implementada
// na Etapa 8/9.
//
// O cadastro de uma validade acontece nos detalhes do produto (tela
// Produtos → botão "🔗"), seguindo o mesmo padrão já usado para
// códigos de barras — esta tela é só de leitura/remoção e navegação
// até o produto.

import { listarTodasValidades, removerValidade } from '../db/expirations.js';
import { obterProduto } from '../db/products.js';
import { abrirDetalhesProduto } from './products.js';
import { renderExpirationCardHTML } from '../components/expiration-card.js';
import { classificarValidade } from '../utils/dates.js';
import { registrarEvento } from '../db/history.js';
import { showToast } from '../components/toast.js';

const LISTA_ID = 'validades-lista';

// Ordem de urgência para agrupar a lista (menor número = mais urgente).
const PRIORIDADE_STATUS = { vencido: 0, critico: 1, atencao: 2, normal: 3 };

/** Busca todas as validades já com o produto correspondente carregado. */
async function carregarValidadesComProduto() {
  const validades = await listarTodasValidades();
  return Promise.all(
    validades.map(async (validade) => ({
      validade,
      produto: await obterProduto(validade.produtoId),
    }))
  );
}

function ordenarPorUrgencia(itens) {
  return [...itens].sort((a, b) => {
    const statusA = classificarValidade(a.validade.dataValidade);
    const statusB = classificarValidade(b.validade.dataValidade);
    const diffPrioridade = PRIORIDADE_STATUS[statusA] - PRIORIDADE_STATUS[statusB];
    if (diffPrioridade !== 0) {
      return diffPrioridade;
    }
    return new Date(a.validade.dataValidade) - new Date(b.validade.dataValidade);
  });
}

/** Renderiza a lista completa. Exportada para ser chamada ao entrar na tela. */
export async function renderizarListaValidades() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  const itens = ordenarPorUrgencia(await carregarValidadesComProduto());

  if (itens.length === 0) {
    listaEl.innerHTML =
      '<p class="empty-state">Nenhuma validade cadastrada ainda. Adicione pelos detalhes de um produto, na tela Produtos.</p>';
    return;
  }

  listaEl.innerHTML = itens
    .map(({ validade, produto }) =>
      renderExpirationCardHTML(validade, {
        nomeProduto: produto ? produto.nome : `Produto #${validade.produtoId} (removido)`,
      })
    )
    .join('');
}

function ligarEventosDaLista() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  listaEl.addEventListener('click', async (e) => {
    const itemEl = e.target.closest('.expiration-item');
    if (!itemEl) {
      return;
    }
    const id = Number(itemEl.dataset.id);
    const produtoId = Number(itemEl.dataset.produtoId);

    const btnRemover = e.target.closest('button[data-action="remover-validade"]');
    if (btnRemover) {
      const confirmado = window.confirm('Remover esta validade?');
      if (!confirmado) {
        return;
      }
      // Bug corrigido na Etapa 15: remover uma validade por aqui (tela
      // Validades) não registrava evento no Histórico — só removendo
      // pelos detalhes do produto (js/pages/products.js) isso
      // acontecia. Agora os dois caminhos registram o mesmo tipo de
      // evento ('validade_removida'), com a mesma descrição.
      const produto = await obterProduto(produtoId);
      await removerValidade(id);
      showToast('Validade removida.');
      await registrarEvento({
        tipo: 'validade_removida',
        descricao: produto
          ? `Uma validade de "${produto.nome}" foi removida.`
          : `Uma validade do produto #${produtoId} (removido) foi removida.`,
        produtoId,
      });
      await renderizarListaValidades();
      return;
    }

    const areaDetalhes = e.target.closest('[data-action="detalhes"]');
    if (areaDetalhes) {
      const produto = await obterProduto(produtoId);
      if (produto) {
        abrirDetalhesProduto(produto);
      }
    }
  });
}

/** Inicializa a tela de Validades (chamado uma vez pelo app.js). */
export function initExpirationsPage() {
  ligarEventosDaLista();
  renderizarListaValidades();
}
