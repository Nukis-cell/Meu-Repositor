// js/pages/products.js
// Tela Produtos: cadastro/listagem de produtos e gerenciamento de
// múltiplos códigos de barras por produto.
//
// Etapa 5: tela de detalhes do produto com lista de códigos de
// barras associados, adição de novo código (entrada manual) e
// remoção de código, com verificação de conflito (um código não
// pode pertencer a dois produtos).
//
// Etapa 6: adição de código também pela câmera (leitor de código de
// barras), usando o mesmo fluxo de validação/conflito da entrada
// manual. `abrirDetalhesProduto` e `abrirFormularioNovoProduto` são
// exportados para reuso pela tela Início (ação "Escanear produto").
//
// Etapa 7: card do produto ganhou o botão "📦 Repor" (marca o
// produto na lista de reposição); `refreshProductsPage` é exportada
// para a lista ser atualizada ao reabrir a aba Produtos (reflete
// reposições concluídas na tela Reposição, por exemplo).
//
// Etapa 8/9: os detalhes do produto (mesmo modal aberto pelo botão
// "🔗") ganharam uma segunda seção, "Validades" — segue o mesmo
// padrão já usado para códigos de barras (lista + formulário de
// adicionar, sem tela própria de cadastro). A tela Validades
// (js/pages/expirations.js) apenas lista, em um só lugar, as
// validades de todos os produtos.

import {
  criarProduto,
  obterProduto,
  listarProdutos,
  atualizarProduto,
  removerProduto,
  buscarProdutoDuplicado,
} from '../db/products.js';
import {
  associarCodigo,
  buscarCodigo,
  listarCodigosDoProduto,
  removerCodigo,
} from '../db/barcodes.js';
import { adicionarReposicao, listarPendentes } from '../db/replenishment.js';
import { cadastrarValidade, listarValidadesDoProduto, removerValidade } from '../db/expirations.js';
import { registrarEvento } from '../db/history.js';
import { renderProductCardHTML } from '../components/product-card.js';
import { renderExpirationCardHTML } from '../components/expiration-card.js';
import { openModal, closeModal } from '../components/modal.js';
import { openScanner, closeScanner } from '../components/barcode-scanner.js';
import { showToast } from '../components/toast.js';
import { escapeHTML } from '../utils/formatters.js';

const LISTA_ID = 'produtos-lista';
const BOTAO_NOVO_ID = 'produtos-btn-novo';
const BUSCA_ID = 'produtos-busca';
const FILTRO_MARCA_ID = 'produtos-filtro-marca';

// Estado dos filtros da lista de produtos (Ajuste pós-Etapa 12, item 3).
// Mantido em memória (não persiste entre sessões) — sempre que a
// lista é recarregada (renderizarLista), os filtros atuais são
// reaplicados.
let filtroBusca = '';
let filtroMarca = '';

function normalizarTexto(texto) {
  return String(texto || '').trim().toLowerCase();
}

// ---------------------------------------------------------------------
// Formulário de produto (criar/editar) — igual à Etapa 4
// ---------------------------------------------------------------------

function formularioProdutoHTML(produto = {}) {
  return `
    <form id="form-produto" novalidate>
      <label class="form-label" for="input-nome">Nome *</label>
      <input class="form-input" id="input-nome" name="nome" type="text"
             value="${escapeHTML(produto.nome ?? '')}" required autofocus />

      <label class="form-label" for="input-marca">Marca</label>
      <input class="form-input" id="input-marca" name="marca" type="text"
             value="${escapeHTML(produto.marca ?? '')}" />

      <label class="form-label" for="input-categoria">Categoria</label>
      <input class="form-input" id="input-categoria" name="categoria" type="text"
             value="${escapeHTML(produto.categoria ?? '')}" />

      <p class="form-error is-hidden" id="form-produto-erro"></p>

      <button type="submit" class="btn btn-primary btn-block">Salvar</button>
    </form>
  `;
}

/** Monta o aviso exibido quando já existe um produto com o mesmo nome e marca. */
function avisoDuplicidadeHTML(produtoExistente) {
  const detalhes = [produtoExistente.marca, produtoExistente.categoria].filter(Boolean).join(' · ');
  return `
    <div class="form-warning" id="aviso-duplicidade">
      <p>⚠️ Já existe um produto cadastrado com esse nome e marca:</p>
      <p class="scan-result-nome">${escapeHTML(produtoExistente.nome)}</p>
      ${detalhes ? `<p class="scan-result-detalhes">${escapeHTML(detalhes)}</p>` : ''}
      <button type="button" class="btn btn-primary btn-block" id="btn-usar-existente">Usar este produto</button>
      <button type="button" class="btn btn-secondary btn-block" id="btn-cadastrar-mesmo-assim">
        Cadastrar mesmo assim (é diferente)
      </button>
    </div>
  `;
}

/** Cria o produto de fato (sem checar duplicidade) e finaliza o formulário. Reutilizado tanto no caminho normal quanto após o usuário confirmar "cadastrar mesmo assim". */
async function criarProdutoEFinalizar(body, dados, codigoParaAssociar) {
  try {
    const id = await criarProduto(dados);
    if (codigoParaAssociar) {
      await associarCodigo(codigoParaAssociar, id);
    }
    closeModal();
    showToast(
      codigoParaAssociar
        ? 'Produto cadastrado e código associado.'
        : 'Produto cadastrado.'
    );
    await registrarEvento({
      tipo: 'produto_criado',
      descricao: `Produto "${dados.nome}" cadastrado.`,
      produtoId: id,
    });
    await renderizarLista();
  } catch (err) {
    exibirErroFormulario(body, err.message);
  }
}

/** Associa o código escaneado/digitado (se houver) ao produto já existente, em vez de criar um novo. */
async function usarProdutoExistente(produtoExistente, codigoParaAssociar) {
  if (codigoParaAssociar) {
    try {
      await associarCodigo(codigoParaAssociar, produtoExistente.id);
    } catch (err) {
      // Código já associado a este mesmo produto ou conflito raro —
      // não impede o fluxo de "usar produto existente".
    }
  }
  closeModal();
  showToast(
    codigoParaAssociar
      ? `Código associado a "${produtoExistente.nome}".`
      : `"${produtoExistente.nome}" já estava cadastrado.`
  );
  await renderizarLista();
}

/** Exibe o aviso de duplicidade dentro do formulário, com as duas opções de resolução. */
function mostrarAvisoDuplicidade(body, form, dados, produtoExistente, codigoParaAssociar) {
  const erroEl = body.querySelector('#form-produto-erro');
  erroEl.classList.add('is-hidden');

  const antigo = body.querySelector('#aviso-duplicidade');
  if (antigo) {
    antigo.remove();
  }
  erroEl.insertAdjacentHTML('afterend', avisoDuplicidadeHTML(produtoExistente));
  const avisoEl = body.querySelector('#aviso-duplicidade');

  const btnSubmit = form.querySelector('button[type="submit"]');
  btnSubmit.disabled = true;

  avisoEl.querySelector('#btn-usar-existente').addEventListener('click', () => {
    usarProdutoExistente(produtoExistente, codigoParaAssociar);
  });

  avisoEl.querySelector('#btn-cadastrar-mesmo-assim').addEventListener('click', async () => {
    avisoEl.remove();
    btnSubmit.disabled = false;
    await criarProdutoEFinalizar(body, dados, codigoParaAssociar);
  });
}

/**
 * Abre o formulário de cadastro de novo produto.
 * @param {{codigoParaAssociar?: string}} opcoes Quando informado (ex.:
 *   vindo do escaneamento na tela Início, Etapa 6), o código é
 *   associado automaticamente ao produto assim que ele é criado.
 */
export function abrirFormularioNovoProduto({ codigoParaAssociar } = {}) {
  openModal({
    title: 'Novo produto',
    bodyHTML: formularioProdutoHTML(),
    onMount: (body) => {
      const form = body.querySelector('#form-produto');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const dados = Object.fromEntries(new FormData(form).entries());

        const duplicado = await buscarProdutoDuplicado(dados.nome, dados.marca);
        if (duplicado) {
          mostrarAvisoDuplicidade(body, form, dados, duplicado, codigoParaAssociar);
          return;
        }

        await criarProdutoEFinalizar(body, dados, codigoParaAssociar);
      });
    },
  });
}

function abrirFormularioEditarProduto(produto) {
  openModal({
    title: 'Editar produto',
    bodyHTML: formularioProdutoHTML(produto),
    onMount: (body) => {
      const form = body.querySelector('#form-produto');
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const dados = Object.fromEntries(new FormData(form).entries());
        try {
          await atualizarProduto(produto.id, dados);
          closeModal();
          showToast('Produto atualizado.');
          await registrarEvento({
            tipo: 'produto_editado',
            descricao: `Produto "${dados.nome}" editado.`,
            produtoId: produto.id,
          });
          await renderizarLista();
        } catch (err) {
          exibirErroFormulario(body, err.message);
        }
      });
    },
  });
}

function exibirErroFormulario(body, mensagem, seletor = '#form-produto-erro') {
  const erroEl = body.querySelector(seletor);
  erroEl.textContent = mensagem;
  erroEl.classList.remove('is-hidden');
}

async function confirmarExclusao(produto) {
  const confirmado = window.confirm(`Excluir "${produto.nome}"?`);
  if (!confirmado) {
    return;
  }
  await removerProduto(produto.id);
  showToast('Produto excluído.');
  await registrarEvento({
    tipo: 'produto_excluido',
    descricao: `Produto "${produto.nome}" excluído.`,
    produtoId: produto.id,
  });
  await renderizarLista();
}

// ---------------------------------------------------------------------
// Detalhes do produto: gerenciamento de códigos de barras (Etapa 5)
// ---------------------------------------------------------------------

function codigoItemHTML(codigo) {
  return `
    <li class="barcode-item" data-codigo="${escapeHTML(codigo.codigo)}">
      <span class="barcode-code">${escapeHTML(codigo.codigo)}</span>
      <button type="button" class="btn-icon" data-action="remover-codigo" aria-label="Remover código">🗑️</button>
    </li>
  `;
}

function detalhesModalBodyHTML(codigos, validades) {
  const listaCodigosHTML = codigos.length
    ? `<ul class="barcode-list" id="barcode-list">${codigos.map(codigoItemHTML).join('')}</ul>`
    : `<p class="empty-state" id="barcode-list-empty">Nenhum código associado ainda.</p>`;

  const listaValidadesHTML = validadeListHTML(validades);

  return `
    <h4 class="form-label" style="margin-top:0">Códigos de barras</h4>
    <div id="barcode-list-container">${listaCodigosHTML}</div>

    <form id="form-codigo" novalidate>
      <label class="form-label" for="input-codigo">Adicionar código</label>
      <input class="form-input" id="input-codigo" name="codigo" type="text"
             inputmode="numeric" placeholder="Digite o código de barras" />
      <p class="form-error is-hidden" id="form-codigo-erro"></p>
      <div class="form-actions-row">
        <button type="button" class="btn btn-secondary" id="btn-escanear-codigo">📷 Escanear</button>
        <button type="submit" class="btn btn-primary">+ Adicionar</button>
      </div>
    </form>

    <h4 class="form-label">Validades</h4>
    <div id="expiration-list-container">${listaValidadesHTML}</div>

    <form id="form-validade" novalidate>
      <label class="form-label" for="input-data-validade">Adicionar validade</label>
      <input class="form-input" id="input-data-validade" name="dataValidade" type="date" required />
      <p class="form-error is-hidden" id="form-validade-erro"></p>
      <button type="submit" class="btn btn-secondary btn-block">+ Adicionar validade</button>
    </form>
  `;
}

/** Monta o HTML da lista de validades de um produto (ou o estado vazio). */
function validadeListHTML(validades) {
  if (!validades.length) {
    return `<p class="empty-state" id="expiration-list-empty">Nenhuma validade cadastrada ainda.</p>`;
  }
  const ordenadas = [...validades].sort(
    (a, b) => new Date(a.dataValidade) - new Date(b.dataValidade)
  );
  return `<div class="expiration-list" id="expiration-list">${ordenadas
    .map((v) => renderExpirationCardHTML(v))
    .join('')}</div>`;
}

async function renderizarListaDeCodigos(container, produtoId) {
  const codigos = await listarCodigosDoProduto(produtoId);
  const listaHTML = codigos.length
    ? `<ul class="barcode-list" id="barcode-list">${codigos.map(codigoItemHTML).join('')}</ul>`
    : `<p class="empty-state" id="barcode-list-empty">Nenhum código associado ainda.</p>`;
  container.innerHTML = listaHTML;
}

/** Atualiza a lista de validades dentro dos detalhes do produto (Etapa 8/9). */
async function renderizarListaDeValidades(container, produtoId) {
  const validades = await listarValidadesDoProduto(produtoId);
  container.innerHTML = validadeListHTML(validades);
}

export async function abrirDetalhesProduto(produto) {
  const [codigosIniciais, validadesIniciais] = await Promise.all([
    listarCodigosDoProduto(produto.id),
    listarValidadesDoProduto(produto.id),
  ]);

  openModal({
    title: produto.nome,
    bodyHTML: detalhesModalBodyHTML(codigosIniciais, validadesIniciais),
    onMount: (body) => {
      const listContainer = body.querySelector('#barcode-list-container');
      const form = body.querySelector('#form-codigo');
      const input = body.querySelector('#input-codigo');
      const btnEscanear = body.querySelector('#btn-escanear-codigo');
      const expirationListContainer = body.querySelector('#expiration-list-container');
      const formValidade = body.querySelector('#form-validade');
      const inputDataValidade = body.querySelector('#input-data-validade');

      // Adicionar código (entrada manual pelo próprio formulário)
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const codigo = input.value.trim();
        const erroEl = body.querySelector('#form-codigo-erro');
        erroEl.classList.add('is-hidden');

        if (!codigo) {
          exibirErroFormulario(body, 'Digite um código.', '#form-codigo-erro');
          return;
        }

        const sucesso = await tentarAdicionarCodigo(body, listContainer, produto, codigo);
        if (sucesso) {
          input.value = '';
        }
      });

      // Adicionar código pela câmera (Etapa 6) — abre o leitor e usa o
      // mesmo fluxo de validação/conflito do formulário manual.
      btnEscanear.addEventListener('click', () => {
        openScanner({
          titulo: `Escanear código — ${produto.nome}`,
          onDetected: async (codigo) => {
            closeScanner();
            await tentarAdicionarCodigo(body, listContainer, produto, codigo);
          },
        });
      });

      // Remover código (delegação de evento na lista)
      listContainer.addEventListener('click', async (e) => {
        const btn = e.target.closest('button[data-action="remover-codigo"]');
        if (!btn) {
          return;
        }
        const item = btn.closest('.barcode-item');
        const codigo = item.dataset.codigo;
        const confirmado = window.confirm(`Remover o código ${codigo}?`);
        if (!confirmado) {
          return;
        }
        await removerCodigo(codigo);
        await renderizarListaDeCodigos(listContainer, produto.id);
        showToast('Código removido.');
        await registrarEvento({
          tipo: 'codigo_removido',
          descricao: `Código ${codigo} removido de "${produto.nome}".`,
          produtoId: produto.id,
        });
      });

      // Adicionar validade (Etapa 8/9)
      formValidade.addEventListener('submit', async (e) => {
        e.preventDefault();
        const erroEl = body.querySelector('#form-validade-erro');
        erroEl.classList.add('is-hidden');

        const dataValidade = inputDataValidade.value;
        if (!dataValidade) {
          erroEl.textContent = 'Escolha uma data.';
          erroEl.classList.remove('is-hidden');
          return;
        }

        await cadastrarValidade({ produtoId: produto.id, dataValidade });
        await renderizarListaDeValidades(expirationListContainer, produto.id);
        inputDataValidade.value = '';
        showToast('Validade adicionada.');
        await registrarEvento({
          tipo: 'validade_cadastrada',
          descricao: `Validade ${dataValidade.split('-').reverse().join('/')} cadastrada para "${produto.nome}".`,
          produtoId: produto.id,
        });
      });

      // Remover validade (delegação de evento na lista)
      expirationListContainer.addEventListener('click', async (e) => {
        const btn = e.target.closest('button[data-action="remover-validade"]');
        if (!btn) {
          return;
        }
        const confirmado = window.confirm('Remover esta validade?');
        if (!confirmado) {
          return;
        }
        const id = Number(btn.closest('.expiration-item').dataset.id);
        await removerValidade(id);
        await renderizarListaDeValidades(expirationListContainer, produto.id);
        showToast('Validade removida.');
        await registrarEvento({
          tipo: 'validade_removida',
          descricao: `Uma validade de "${produto.nome}" foi removida.`,
          produtoId: produto.id,
        });
      });
    },
  });
}

/**
 * Associa um código ao produto (manual ou via câmera), tratando erro
 * de conflito e atualizando a lista/toast em caso de sucesso.
 * @returns {Promise<boolean>} true se o código foi associado com sucesso
 */
async function tentarAdicionarCodigo(body, listContainer, produto, codigo) {
  const erroEl = body.querySelector('#form-codigo-erro');
  erroEl.classList.add('is-hidden');

  try {
    await associarCodigo(codigo, produto.id);
    await renderizarListaDeCodigos(listContainer, produto.id);
    showToast('Código adicionado.');
    await registrarEvento({
      tipo: 'codigo_adicionado',
      descricao: `Código ${codigo} adicionado a "${produto.nome}".`,
      produtoId: produto.id,
    });
    return true;
  } catch (err) {
    const mensagem = await mensagemDeConflito(codigo, produto.id, err);
    exibirErroFormulario(body, mensagem, '#form-codigo-erro');
    return false;
  }
}

/** Monta uma mensagem de erro amigável quando um código já pertence a outro produto. */
async function mensagemDeConflito(codigo, produtoId, err) {
  const existente = await buscarCodigo(codigo);
  if (existente && existente.produtoId !== produtoId) {
    const produtoConflitante = await obterProduto(existente.produtoId);
    const nome = produtoConflitante ? produtoConflitante.nome : `produto #${existente.produtoId}`;
    return `Este código já está associado a "${nome}".`;
  }
  return err.message;
}

// ---------------------------------------------------------------------
// Lista de produtos
// ---------------------------------------------------------------------

/** Verifica se um produto passa nos filtros de busca/marca atuais. */
function produtoCorrespondeAosFiltros(produto) {
  const nomeOk = !filtroBusca || normalizarTexto(produto.nome).includes(filtroBusca);
  const marcaOk = !filtroMarca || normalizarTexto(produto.marca) === filtroMarca;
  return nomeOk && marcaOk;
}

/** Extrai a lista de marcas distintas dos produtos (sem diferenciar maiúsculas/minúsculas), ordenada. */
function marcasDistintas(produtos) {
  const mapa = new Map(); // chave: marca normalizada, valor: marca como foi digitada
  produtos.forEach((produto) => {
    const marca = (produto.marca || '').trim();
    if (!marca) {
      return;
    }
    const chave = normalizarTexto(marca);
    if (!mapa.has(chave)) {
      mapa.set(chave, marca);
    }
  });
  return [...mapa.entries()].sort((a, b) => a[1].localeCompare(b[1], 'pt-BR'));
}

/** Reconstrói as opções do filtro de marca a partir dos produtos atuais, preservando a seleção quando possível. */
function atualizarOpcoesDeMarca(produtos) {
  const selectEl = document.getElementById(FILTRO_MARCA_ID);
  if (!selectEl) {
    return;
  }

  const marcas = marcasDistintas(produtos);
  const opcoesHTML = ['<option value="">Todas as marcas</option>']
    .concat(marcas.map(([chave, marca]) => `<option value="${escapeHTML(chave)}">${escapeHTML(marca)}</option>`))
    .join('');

  selectEl.innerHTML = opcoesHTML;

  if (marcas.some(([chave]) => chave === filtroMarca)) {
    selectEl.value = filtroMarca;
  } else {
    // A marca antes selecionada não existe mais (ex.: era a única e o
    // produto foi excluído/editado) — volta para "Todas as marcas".
    selectEl.value = '';
    filtroMarca = '';
  }
}

async function renderizarLista() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  const [produtos, pendentes] = await Promise.all([listarProdutos(), listarPendentes()]);

  atualizarOpcoesDeMarca(produtos);

  if (produtos.length === 0) {
    listaEl.innerHTML = '<p class="empty-state">Nenhum produto cadastrado ainda.</p>';
    return;
  }

  const filtrados = produtos.filter(produtoCorrespondeAosFiltros);
  if (filtrados.length === 0) {
    listaEl.innerHTML = '<p class="empty-state">Nenhum produto encontrado com esse filtro.</p>';
    return;
  }

  const idsComReposicaoPendente = new Set(pendentes.map((item) => item.produtoId));

  filtrados.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
  listaEl.innerHTML = filtrados
    .map((produto) =>
      renderProductCardHTML(produto, {
        pendenteReposicao: idsComReposicaoPendente.has(produto.id),
      })
    )
    .join('');
}

/** Liga a busca por nome e o filtro por marca da tela Produtos. */
function ligarFiltros() {
  const inputBusca = document.getElementById(BUSCA_ID);
  const selectMarca = document.getElementById(FILTRO_MARCA_ID);

  if (inputBusca) {
    inputBusca.addEventListener('input', () => {
      filtroBusca = normalizarTexto(inputBusca.value);
      renderizarLista();
    });
  }

  if (selectMarca) {
    selectMarca.addEventListener('change', () => {
      filtroMarca = selectMarca.value;
      renderizarLista();
    });
  }
}

function ligarEventosDaLista() {
  const listaEl = document.getElementById(LISTA_ID);
  if (!listaEl) {
    return;
  }

  listaEl.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) {
      return;
    }

    const cardEl = btn.closest('.product-card');
    const produtoId = Number(cardEl.dataset.produtoId);
    const produto = await obterProduto(produtoId);
    if (!produto) {
      return;
    }

    const acao = btn.dataset.action;
    if (acao === 'editar') {
      abrirFormularioEditarProduto(produto);
    } else if (acao === 'excluir') {
      confirmarExclusao(produto);
    } else if (acao === 'codigos') {
      abrirDetalhesProduto(produto);
    } else if (acao === 'repor') {
      await adicionarReposicao(produto.id);
      showToast('Produto marcado para repor.');
      await registrarEvento({
        tipo: 'reposicao_marcada',
        descricao: `"${produto.nome}" marcado para repor.`,
        produtoId: produto.id,
      });
      await renderizarLista();
    }
  });
}

/** Inicializa a tela de Produtos (chamado uma vez pelo app.js). */
export function initProductsPage() {
  const btnNovo = document.getElementById(BOTAO_NOVO_ID);
  if (btnNovo) {
    btnNovo.addEventListener('click', abrirFormularioNovoProduto);
  }
  ligarEventosDaLista();
  ligarFiltros();
  renderizarLista();
}

/** Atualiza a lista de produtos (ex.: chamada pelo app.js ao reabrir a aba Produtos). */
export function refreshProductsPage() {
  return renderizarLista();
}
