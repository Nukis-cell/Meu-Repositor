// js/pages/home.js
// Tela Início: resumos de reposição pendente, validades próximas e
// quantidade de produtos cadastrados (Etapa 10 — Dashboard), além da
// ação rápida "📷 Escanear produto" (Etapa 6).

import { buscarCodigo } from '../db/barcodes.js';
import { obterProduto, listarProdutos } from '../db/products.js';
import { listarPendentes, adicionarReposicao, obterPendentePorProduto } from '../db/replenishment.js';
import { listarTodasValidades } from '../db/expirations.js';
import { classificarValidade } from '../utils/dates.js';
import { abrirDetalhesProduto, abrirFormularioNovoProduto } from './products.js';
import { openScanner, closeScanner } from '../components/barcode-scanner.js';
import { openModal, closeModal } from '../components/modal.js';
import { registrarEvento } from '../db/history.js';
import { showToast } from '../components/toast.js';
import { escapeHTML } from '../utils/formatters.js';

const BOTAO_ESCANEAR_ID = 'home-btn-escanear';

const SUMMARY_IDS = {
  reposicao: 'home-summary-reposicao',
  validades: 'home-summary-validades',
  produtos: 'home-summary-produtos',
};

// Navegar para a aba correspondente ao tocar num card de resumo
// (reaproveita os mesmos botões da navegação inferior).
const SUMMARY_TARGET = {
  reposicao: 'reposicao',
  validades: 'validades',
  produtos: 'produtos',
};

/** Conta quantas validades precisam de atenção (vencidas, críticas ou em atenção). */
async function contarValidadesProximas() {
  const validades = await listarTodasValidades();
  return validades.filter((v) => classificarValidade(v.dataValidade) !== 'normal').length;
}

/** Atualiza os três cards de resumo da tela Início. Exportada para ser chamada ao entrar na tela. */
export async function renderResumoHome() {
  const elReposicao = document.getElementById(SUMMARY_IDS.reposicao);
  const elValidades = document.getElementById(SUMMARY_IDS.validades);
  const elProdutos = document.getElementById(SUMMARY_IDS.produtos);
  if (!elReposicao || !elValidades || !elProdutos) {
    return;
  }

  const [pendentes, validadesProximas, produtos] = await Promise.all([
    listarPendentes(),
    contarValidadesProximas(),
    listarProdutos(),
  ]);

  elReposicao.textContent = String(pendentes.length);
  elValidades.textContent = String(validadesProximas);
  elProdutos.textContent = String(produtos.length);
}

function ligarCliqueNosCards() {
  Object.entries(SUMMARY_TARGET).forEach(([chave, target]) => {
    const card = document.getElementById(SUMMARY_IDS[chave])?.closest('.summary-card');
    if (!card) {
      return;
    }
    card.addEventListener('click', () => {
      document.querySelector(`.nav-item[data-target="${target}"]`)?.click();
    });
  });
}

/** Monta o corpo do modal de ação rápida exibido após um produto ser identificado por escaneamento. */
function acoesRapidasModalHTML(produto, jaPendente) {
  const detalhes = [produto.marca, produto.categoria].filter(Boolean).join(' · ');

  return `
    <div class="scan-result">
      <p class="scan-result-nome">${escapeHTML(produto.nome)}</p>
      ${detalhes ? `<p class="scan-result-detalhes">${escapeHTML(detalhes)}</p>` : ''}
    </div>
    <button type="button" class="btn btn-primary btn-block" id="scan-btn-repor" ${jaPendente ? 'disabled' : ''}>
      ${jaPendente ? '✅ Já está na lista de reposição' : '📦 Adicionar para reposição'}
    </button>
    <button type="button" class="btn btn-secondary btn-block" id="scan-btn-detalhes">
      🔗 Ver detalhes / códigos
    </button>
  `;
}

/**
 * Abre um modal de ação rápida para um produto já identificado pelo
 * escaneamento, com a opção de já marcá-lo para repor sem precisar
 * entrar na tela de detalhes.
 */
async function abrirAcoesRapidasDoProduto(produto) {
  const jaPendente = Boolean(await obterPendentePorProduto(produto.id));

  openModal({
    title: 'Produto encontrado',
    bodyHTML: acoesRapidasModalHTML(produto, jaPendente),
    onMount: (body) => {
      const btnRepor = body.querySelector('#scan-btn-repor');
      const btnDetalhes = body.querySelector('#scan-btn-detalhes');

      if (!jaPendente) {
        btnRepor.addEventListener('click', async () => {
          await adicionarReposicao(produto.id);
          closeModal();
          showToast('Produto marcado para repor.');
          await registrarEvento({
            tipo: 'reposicao_marcada',
            descricao: `"${produto.nome}" marcado para repor.`,
            produtoId: produto.id,
          });
          await renderResumoHome();
        });
      }

      btnDetalhes.addEventListener('click', async () => {
        closeModal();
        await abrirDetalhesProduto(produto);
      });
    },
  });
}

async function tratarCodigoEscaneado(codigo) {
  const associacao = await buscarCodigo(codigo);

  if (!associacao) {
    showToast(`Código ${codigo} não cadastrado. Cadastre o produto.`);
    abrirFormularioNovoProduto({ codigoParaAssociar: codigo });
    return;
  }

  const produto = await obterProduto(associacao.produtoId);
  if (!produto) {
    // Situação rara (dado inconsistente): código aponta para um
    // produto que não existe mais. Trata como não encontrado.
    showToast(`Código ${codigo} não cadastrado. Cadastre o produto.`);
    abrirFormularioNovoProduto({ codigoParaAssociar: codigo });
    return;
  }

  await abrirAcoesRapidasDoProduto(produto);
}

function abrirScannerDeIdentificacao() {
  openScanner({
    titulo: 'Escanear produto',
    onDetected: async (codigo) => {
      closeScanner();
      await tratarCodigoEscaneado(codigo);
    },
  });
}

/** Inicializa a tela Início (chamado uma vez pelo app.js). */
export function initHomePage() {
  const btnEscanear = document.getElementById(BOTAO_ESCANEAR_ID);
  if (btnEscanear) {
    btnEscanear.addEventListener('click', abrirScannerDeIdentificacao);
  }
  ligarCliqueNosCards();
  renderResumoHome();
}
