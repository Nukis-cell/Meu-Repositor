// js/pages/settings.js
// Tela Configurações: acesso ao Histórico (Etapa 11), Backup e
// restauração (Etapa 12) e Diagnóstico (Etapa 13).

import { listarHistorico, limparHistorico, registrarEvento } from '../db/history.js';
import { gerarBackup, restaurarBackup, pareceBackupValido } from '../db/backup.js';
import { openModal, closeModal } from '../components/modal.js';
import { showToast } from '../components/toast.js';
import { escapeHTML } from '../utils/formatters.js';
import { lerStorage, salvarStorage } from '../utils/storage.js';
import { listarErros, limparErros } from '../utils/errorlog.js';
import { APP_NAME, DB_VERSION } from '../config/config.js';

const BOTAO_HISTORICO_ID = 'config-btn-historico';
const BOTAO_BACKUP_ID = 'config-btn-backup';
const BOTAO_RESTAURAR_ID = 'config-btn-restaurar';
const INPUT_RESTAURAR_ID = 'config-input-restaurar';
const ULTIMO_BACKUP_TEXTO_ID = 'config-ultimo-backup';
const BOTAO_DIAGNOSTICO_ID = 'config-btn-diagnostico';

// Chave usada no localStorage (via js/utils/storage.js) para lembrar
// quando foi o último backup — é só uma informação de conveniência
// para o usuário, não faz parte dos dados do app.
const CHAVE_ULTIMO_BACKUP = 'ultimoBackupEm';

const TIPO_ICONE = {
  produto_criado: '🆕',
  produto_editado: '✏️',
  produto_excluido: '🗑️',
  codigo_adicionado: '🔗',
  codigo_removido: '🔗',
  reposicao_marcada: '📦',
  reposicao_concluida: '✅',
  reposicao_falta: '🚫',
  validade_cadastrada: '📅',
  validade_removida: '📅',
  backup_restaurado: '♻️',
};

function formatarDataHora(iso) {
  const data = new Date(iso);
  return `${data.toLocaleDateString('pt-BR')} às ${data.toLocaleTimeString('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  })}`;
}

function eventoItemHTML(evento) {
  const icone = TIPO_ICONE[evento.tipo] || '•';
  return `
    <li class="history-item">
      <span class="history-item-icone">${icone}</span>
      <span class="history-item-info">
        <span class="history-item-descricao">${escapeHTML(evento.descricao)}</span>
        <span class="history-item-data">${formatarDataHora(evento.criadoEm)}</span>
      </span>
    </li>
  `;
}

function historicoModalBodyHTML(eventos) {
  const listaHTML = eventos.length
    ? `<ul class="history-list" id="history-list">${eventos.map(eventoItemHTML).join('')}</ul>`
    : `<p class="empty-state" id="history-list-empty">Nenhum evento registrado ainda.</p>`;

  return `
    <div id="history-list-container">${listaHTML}</div>
    ${eventos.length ? `<button type="button" class="btn btn-secondary btn-block" id="btn-limpar-historico">Limpar histórico</button>` : ''}
  `;
}

/** Busca e ordena o histórico (mais recente primeiro). */
async function carregarHistoricoOrdenado() {
  const eventos = await listarHistorico();
  return eventos.sort((a, b) => new Date(b.criadoEm) - new Date(a.criadoEm));
}

async function abrirHistorico() {
  const eventos = await carregarHistoricoOrdenado();

  openModal({
    title: 'Histórico',
    bodyHTML: historicoModalBodyHTML(eventos),
    onMount: (body) => {
      const btnLimpar = body.querySelector('#btn-limpar-historico');
      if (!btnLimpar) {
        return;
      }
      btnLimpar.addEventListener('click', async () => {
        const confirmado = window.confirm(
          'Limpar todo o histórico? Essa ação não pode ser desfeita.'
        );
        if (!confirmado) {
          return;
        }
        await limparHistorico();
        closeModal();
        showToast('Histórico limpo.');
      });
    },
  });
}

// ---------------------------------------------------------------------
// Backup e restauração (Etapa 12)
// ---------------------------------------------------------------------

/** Nome de arquivo sugerido para o download do backup, com data e hora. */
function nomeArquivoBackup() {
  const agora = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const data = `${agora.getFullYear()}-${pad(agora.getMonth() + 1)}-${pad(agora.getDate())}`;
  const hora = `${pad(agora.getHours())}${pad(agora.getMinutes())}`;
  return `meu-repositor-backup-${data}-${hora}.json`;
}

/** Atualiza o texto "Último backup: ..." a partir do que está salvo no localStorage. */
function atualizarTextoUltimoBackup() {
  const el = document.getElementById(ULTIMO_BACKUP_TEXTO_ID);
  if (!el) {
    return;
  }
  const salvoEm = lerStorage(CHAVE_ULTIMO_BACKUP);
  el.textContent = salvoEm
    ? `Último backup: ${formatarDataHora(salvoEm)}`
    : 'Nenhum backup feito ainda neste aparelho.';
}

/**
 * Gera o backup completo e dispara o download do arquivo .json,
 * usando um link temporário (técnica padrão em apps client-side sem
 * backend, sem precisar de nenhuma permissão especial do navegador).
 */
async function fazerBackup() {
  // Etapa 14: desabilita o botão e troca o texto durante a operação —
  // evita cliques duplicados (gerando dois downloads) e dá feedback
  // de que algo está acontecendo em aparelhos mais lentos ou com
  // muitos dados cadastrados.
  const btn = document.getElementById(BOTAO_BACKUP_ID);
  const textoOriginal = btn?.textContent;
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Gerando backup...';
  }

  try {
    const backup = await gerarBackup();
    const conteudo = JSON.stringify(backup, null, 2);
    const blob = new Blob([conteudo], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = nomeArquivoBackup();
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);

    salvarStorage(CHAVE_ULTIMO_BACKUP, new Date().toISOString());
    atualizarTextoUltimoBackup();
    showToast('Backup gerado! Verifique a pasta de downloads.');
  } catch (err) {
    console.error('Erro ao gerar backup:', err);
    showToast('Não foi possível gerar o backup.', 'error');
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = textoOriginal;
    }
  }
}

/** Lê um arquivo escolhido pelo usuário como texto (Promise em cima do FileReader). */
function lerArquivoComoTexto(arquivo) {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = () => resolve(leitor.result);
    leitor.onerror = () => reject(leitor.error);
    leitor.readAsText(arquivo);
  });
}

/**
 * Lê, valida e restaura um arquivo de backup escolhido pelo usuário.
 * Pede confirmação explícita antes, porque a restauração substitui
 * TODOS os dados atuais do app — não é uma mesclagem.
 */
async function restaurarDeArquivo(arquivo) {
  let backup;
  try {
    const texto = await lerArquivoComoTexto(arquivo);
    backup = JSON.parse(texto);
  } catch (err) {
    console.error('Erro ao ler arquivo de backup:', err);
    showToast('Arquivo inválido: não é um backup em formato JSON.', 'error');
    return;
  }

  if (!pareceBackupValido(backup)) {
    showToast('Este arquivo não parece ser um backup do Meu Repositor.', 'error');
    return;
  }

  const dataBackup = backup.criadoEm ? formatarDataHora(backup.criadoEm) : 'data desconhecida';
  const confirmado = window.confirm(
    `Restaurar o backup de ${dataBackup}?\n\n` +
      'ATENÇÃO: todos os dados atuais do app (produtos, códigos de barras, ' +
      'reposição, validades e histórico) serão APAGADOS e substituídos ' +
      'pelos dados desse arquivo. Essa ação não pode ser desfeita.'
  );
  if (!confirmado) {
    return;
  }

  // Etapa 14: mesmo feedback de "operação em andamento" do backup —
  // aqui ainda mais importante, já que ler+regravar todas as stores
  // pode levar um instante perceptível com muitos dados cadastrados.
  const btn = document.getElementById(BOTAO_RESTAURAR_ID);
  const textoOriginal = btn?.textContent;
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Restaurando...';
  }

  try {
    await restaurarBackup(backup);
    // Registrado depois da restauração (não antes), para o evento
    // aparecer no histórico já restaurado, como o primeiro item novo.
    await registrarEvento({
      tipo: 'backup_restaurado',
      descricao: `Backup restaurado (arquivo de ${dataBackup}).`,
    });
    showToast('Backup restaurado! Recarregando o app...');
    // Recarrega a página em vez de tentar atualizar cada tela na mão:
    // mais simples e garante que nenhuma tela fique mostrando dados
    // antigos em memória depois de uma troca completa do banco. O
    // botão fica desabilitado até lá de propósito (a página já vai
    // recarregar sozinha em seguida).
    setTimeout(() => window.location.reload(), 1200);
  } catch (err) {
    console.error('Erro ao restaurar backup:', err);
    showToast('Não foi possível restaurar o backup.', 'error');
    if (btn) {
      btn.disabled = false;
      btn.textContent = textoOriginal;
    }
  }
}

// ---------------------------------------------------------------------
// Diagnóstico (Etapa 13)
// ---------------------------------------------------------------------
//
// Reúne, numa única tela, informações que ajudam a entender um
// problema relatado no uso real: o que o navegador suporta, se o
// Service Worker está ativo, quanto espaço está sendo usado, e os
// últimos erros capturados automaticamente (tanto pelo tratamento
// global em js/app.js quanto pelo log de erros de IndexedDB em
// js/db/database.js — ver js/utils/errorlog.js). O botão "Copiar
// diagnóstico" gera um texto único com tudo isso, para o usuário
// colar numa conversa/relato de problema sem precisar descrever cada
// detalhe técnico manualmente.

/** Detecta se o app está rodando "instalado" (modo standalone), em vez de numa aba comum do navegador. */
function rodandoComoAppInstalado() {
  const viaMediaQuery = window.matchMedia?.('(display-mode: standalone)').matches;
  // `navigator.standalone` é a forma específica do Safari/iOS de
  // indicar o mesmo estado (não tem `display-mode` como o Chrome).
  const viaIOS = navigator.standalone === true;
  return Boolean(viaMediaQuery || viaIOS);
}

/** Reúne as informações de ambiente/suporte do navegador e o log de erros. Nunca lança erro — qualquer coleta que falhe vira `null`/valor padrão. */
async function coletarInfoDiagnostico() {
  let armazenamento = null;
  if (navigator.storage?.estimate) {
    try {
      const { usage, quota } = await navigator.storage.estimate();
      armazenamento = {
        usadoMB: (usage / (1024 * 1024)).toFixed(1),
        totalMB: (quota / (1024 * 1024)).toFixed(1),
      };
    } catch (err) {
      console.warn('Não foi possível estimar o uso de armazenamento:', err);
    }
  }

  let cachesAtivos = [];
  if ('caches' in window) {
    try {
      cachesAtivos = await caches.keys();
    } catch (err) {
      console.warn('Não foi possível listar os caches:', err);
    }
  }

  return {
    app: { nome: APP_NAME, dbVersion: DB_VERSION },
    navegador: {
      userAgent: navigator.userAgent,
      idioma: navigator.language,
      online: navigator.onLine,
      instaladoComoApp: rodandoComoAppInstalado(),
    },
    suporte: {
      indexedDB: 'indexedDB' in window,
      serviceWorker: 'serviceWorker' in navigator,
      swAtivo: Boolean(navigator.serviceWorker?.controller),
      leitorCodigoBarras: 'BarcodeDetector' in window,
      areaTransferencia: Boolean(navigator.clipboard?.writeText),
    },
    armazenamento,
    cachesAtivos,
    erros: listarErros(),
  };
}

/** Monta o texto único (para copiar) com todas as informações de diagnóstico. */
function diagnosticoTextoParaCopiar(info) {
  const linhas = [
    `${info.app.nome} — Diagnóstico (${formatarDataHora(new Date().toISOString())})`,
    '',
    `Banco de dados: versão ${info.app.dbVersion}`,
    `Navegador: ${info.navegador.userAgent}`,
    `Idioma: ${info.navegador.idioma} · Online: ${info.navegador.online ? 'sim' : 'não'} · Instalado como app: ${info.navegador.instaladoComoApp ? 'sim' : 'não'}`,
    `Suporte — IndexedDB: ${info.suporte.indexedDB ? 'sim' : 'não'} · Service Worker: ${info.suporte.serviceWorker ? 'sim' : 'não'} (ativo agora: ${info.suporte.swAtivo ? 'sim' : 'não'}) · Leitor de código por câmera: ${info.suporte.leitorCodigoBarras ? 'sim' : 'não'} · Área de transferência: ${info.suporte.areaTransferencia ? 'sim' : 'não'}`,
  ];

  if (info.armazenamento) {
    linhas.push(`Armazenamento: ~${info.armazenamento.usadoMB} MB usados de ~${info.armazenamento.totalMB} MB disponíveis`);
  }
  if (info.cachesAtivos.length) {
    linhas.push(`Caches ativos: ${info.cachesAtivos.join(', ')}`);
  }

  linhas.push('', `Erros registrados: ${info.erros.length}`);
  info.erros.forEach((erro, indice) => {
    const local = erro.contexto ? `${erro.origem} · ${erro.contexto}` : erro.origem;
    linhas.push(`${indice + 1}. [${formatarDataHora(erro.criadoEm)}] (${local}) ${erro.mensagem}`);
  });

  return linhas.join('\n');
}

/** Copia texto para a área de transferência, com fallback para navegadores sem `navigator.clipboard`. */
async function copiarParaAreaDeTransferencia(texto) {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(texto);
      return true;
    } catch (err) {
      console.warn('navigator.clipboard falhou, tentando alternativa:', err);
    }
  }
  // Fallback: campo de texto temporário + comando de cópia do
  // navegador — funciona mesmo sem a API moderna de clipboard.
  try {
    const textarea = document.createElement('textarea');
    textarea.value = texto;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const copiou = document.execCommand('copy');
    textarea.remove();
    return copiou;
  } catch (err) {
    console.warn('Fallback de cópia também falhou:', err);
    return false;
  }
}

function diagErroItemHTML(erro) {
  const local = erro.contexto ? `${erro.origem} · ${erro.contexto}` : erro.origem;
  return `
    <li class="history-item">
      <span class="history-item-icone">⚠️</span>
      <span class="history-item-info">
        <span class="history-item-descricao">${escapeHTML(erro.mensagem)}</span>
        <span class="history-item-data">${escapeHTML(local)} — ${formatarDataHora(erro.criadoEm)}</span>
      </span>
    </li>
  `;
}

function diagnosticoModalBodyHTML(info) {
  const errosHTML = info.erros.length
    ? `<ul class="history-list" id="diag-lista-erros">${info.erros.map(diagErroItemHTML).join('')}</ul>`
    : `<p class="empty-state">Nenhum erro registrado. 🎉</p>`;

  return `
    <div class="diag-section">
      <h4 class="settings-group-title">Ambiente</h4>
      <p class="settings-info">Banco de dados: versão ${info.app.dbVersion}</p>
      <p class="settings-info">IndexedDB: ${info.suporte.indexedDB ? '✅ suportado' : '❌ não suportado'}</p>
      <p class="settings-info">
        Service Worker: ${info.suporte.serviceWorker ? '✅ suportado' : '❌ não suportado'}${info.suporte.serviceWorker ? (info.suporte.swAtivo ? ' (ativo)' : ' (ainda não ativo nesta aba)') : ''}
      </p>
      <p class="settings-info">Leitor de código por câmera: ${info.suporte.leitorCodigoBarras ? '✅ suportado' : '❌ use a entrada manual'}</p>
      <p class="settings-info">Conexão: ${info.navegador.online ? 'online' : 'offline'} · Instalado como app: ${info.navegador.instaladoComoApp ? 'sim' : 'não'}</p>
      ${info.armazenamento ? `<p class="settings-info">Armazenamento: ~${info.armazenamento.usadoMB} MB usados de ~${info.armazenamento.totalMB} MB disponíveis</p>` : ''}
    </div>
    <div class="diag-section">
      <h4 class="settings-group-title">Erros registrados (${info.erros.length})</h4>
      ${errosHTML}
    </div>
    <button type="button" class="btn btn-primary btn-block" id="btn-copiar-diagnostico">
      📋 Copiar diagnóstico
    </button>
    ${info.erros.length ? `<button type="button" class="btn btn-secondary btn-block" id="btn-limpar-erros">Limpar erros registrados</button>` : ''}
  `;
}

async function abrirDiagnostico() {
  const info = await coletarInfoDiagnostico();

  openModal({
    title: 'Diagnóstico',
    bodyHTML: diagnosticoModalBodyHTML(info),
    onMount: (body) => {
      const btnCopiar = body.querySelector('#btn-copiar-diagnostico');
      btnCopiar?.addEventListener('click', async () => {
        const copiou = await copiarParaAreaDeTransferencia(diagnosticoTextoParaCopiar(info));
        showToast(
          copiou ? 'Diagnóstico copiado.' : 'Não foi possível copiar automaticamente.',
          copiou ? 'success' : 'error'
        );
      });

      const btnLimpar = body.querySelector('#btn-limpar-erros');
      btnLimpar?.addEventListener('click', () => {
        const confirmado = window.confirm(
          'Limpar os erros registrados? Essa ação não pode ser desfeita.'
        );
        if (!confirmado) {
          return;
        }
        limparErros();
        closeModal();
        showToast('Erros de diagnóstico limpos.');
      });
    },
  });
}

/** Inicializa a tela de Configurações (chamado uma vez pelo app.js). */
export function initSettingsPage() {
  const btnHistorico = document.getElementById(BOTAO_HISTORICO_ID);
  if (btnHistorico) {
    btnHistorico.addEventListener('click', abrirHistorico);
  }

  const btnBackup = document.getElementById(BOTAO_BACKUP_ID);
  if (btnBackup) {
    btnBackup.addEventListener('click', fazerBackup);
  }

  const btnRestaurar = document.getElementById(BOTAO_RESTAURAR_ID);
  const inputRestaurar = document.getElementById(INPUT_RESTAURAR_ID);
  if (btnRestaurar && inputRestaurar) {
    btnRestaurar.addEventListener('click', () => inputRestaurar.click());
    inputRestaurar.addEventListener('change', async () => {
      const arquivo = inputRestaurar.files && inputRestaurar.files[0];
      // Limpa o valor logo em seguida, para permitir escolher o mesmo
      // arquivo de novo no futuro (o evento "change" não dispara de
      // novo se o value não mudar).
      inputRestaurar.value = '';
      if (arquivo) {
        await restaurarDeArquivo(arquivo);
      }
    });
  }

  const btnDiagnostico = document.getElementById(BOTAO_DIAGNOSTICO_ID);
  if (btnDiagnostico) {
    btnDiagnostico.addEventListener('click', abrirDiagnostico);
  }

  atualizarTextoUltimoBackup();
}
