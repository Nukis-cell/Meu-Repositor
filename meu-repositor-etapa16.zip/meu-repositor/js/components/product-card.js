// js/components/product-card.js
// Componente de exibição de um produto (usado na tela de Produtos e,
// futuramente, em Validades).

import { escapeHTML } from '../utils/formatters.js';

/**
 * Gera o HTML de um card de produto.
 * @param {{id:number, nome:string, marca?:string, categoria?:string}} produto
 * @param {{pendenteReposicao?: boolean}} opcoes Etapa 7: se o produto já
 *   está marcado para repor, o botão "Repor" muda de aparência e fica
 *   desabilitado (evita duplicidade e dá feedback visual imediato).
 * @returns {string}
 */
export function renderProductCardHTML(produto, { pendenteReposicao = false } = {}) {
  const detalhes = [produto.marca, produto.categoria].filter(Boolean).join(' · ');

  return `
    <div class="card product-card" data-produto-id="${produto.id}">
      <div class="product-card-info" data-action="codigos">
        <span class="product-card-nome">${escapeHTML(produto.nome)}</span>
        ${detalhes ? `<span class="product-card-detalhes">${escapeHTML(detalhes)}</span>` : ''}
      </div>
      <div class="product-card-actions">
        <button type="button" class="btn-icon${pendenteReposicao ? ' is-active' : ''}"
                data-action="repor" aria-label="Marcar para repor"
                ${pendenteReposicao ? 'disabled' : ''}>${pendenteReposicao ? '✅' : '📦'}</button>
        <button type="button" class="btn-icon" data-action="codigos" aria-label="Códigos de barras e validades">🔗</button>
        <button type="button" class="btn-icon" data-action="editar" aria-label="Editar produto">✏️</button>
        <button type="button" class="btn-icon" data-action="excluir" aria-label="Excluir produto">🗑️</button>
      </div>
    </div>
  `;
}
