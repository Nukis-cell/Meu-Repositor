// js/components/barcode-scanner.js
// Componente reutilizável do leitor de código de barras.
//
// Usa a API nativa BarcodeDetector (câmera) quando o navegador
// suporta. Quando não suporta, quando a permissão de câmera é negada
// ou indisponível, ou quando o usuário simplesmente prefere, a
// entrada manual fica sempre disponível como alternativa — nunca é
// obrigatório usar a câmera.
//
// Uso:
//   import { openScanner, closeScanner } from './barcode-scanner.js';
//
//   openScanner({
//     titulo: 'Escanear código',
//     onDetected: (codigo, info) => {
//       // info.manual === true  -> código veio da entrada manual
//       // info.manual === false -> código veio da leitura por câmera
//       closeScanner();
//       // ...tratar o código...
//     },
//   });
//
// Quem chama openScanner() é responsável por chamar closeScanner()
// dentro de onDetected() quando quiser fechar o leitor (por exemplo,
// depois de validar o código). Isso permite, por exemplo, manter o
// leitor aberto para tentar de novo em caso de erro.

const FORMATOS_SUPORTADOS = [
  'ean_13',
  'ean_8',
  'upc_a',
  'upc_e',
  'code_128',
  'code_39',
  'itf',
  'codabar',
];

let overlayAtual = null;
let streamAtual = null;
let loopAtivo = false;
let keydownHandlerScanner = null;

function suportaCameraNativa() {
  return 'BarcodeDetector' in window && !!navigator.mediaDevices?.getUserMedia;
}

function pararCamera() {
  loopAtivo = false;
  if (streamAtual) {
    streamAtual.getTracks().forEach((track) => track.stop());
    streamAtual = null;
  }
}

/** Fecha o leitor: para a câmera (se estiver ativa) e remove o overlay. */
export function closeScanner() {
  pararCamera();
  if (overlayAtual) {
    overlayAtual.remove();
    overlayAtual = null;
    document.body.classList.remove('scanner-open');
  }
  if (keydownHandlerScanner) {
    document.removeEventListener('keydown', keydownHandlerScanner);
    keydownHandlerScanner = null;
  }
}

function overlayShellHTML(titulo) {
  return `
    <div class="scanner-box" role="dialog" aria-modal="true" aria-label="${titulo}">
      <div class="scanner-header">
        <h3>${titulo}</h3>
        <button type="button" class="modal-close" id="scanner-btn-fechar" aria-label="Fechar">✕</button>
      </div>
      <div id="scanner-conteudo"></div>
    </div>
  `;
}

function areaVideoHTML() {
  return `
    <div class="scanner-video-wrap">
      <video id="scanner-video" autoplay playsinline muted></video>
      <div class="scanner-frame" aria-hidden="true"></div>
    </div>
    <p class="scanner-hint" id="scanner-hint">Aponte a câmera para o código de barras.</p>
    <button type="button" class="btn btn-secondary btn-block" id="scanner-btn-manual">
      ⌨️ Digitar código manualmente
    </button>
  `;
}

function formularioManualHTML(mensagemTopo) {
  return `
    ${mensagemTopo ? `<p class="scanner-hint">${mensagemTopo}</p>` : ''}
    <form id="scanner-form-manual" novalidate>
      <label class="form-label" for="scanner-input-manual">Código de barras</label>
      <input class="form-input" id="scanner-input-manual" name="codigo" type="text"
             inputmode="numeric" placeholder="Digite o código de barras" autofocus />
      <p class="form-error is-hidden" id="scanner-erro-manual"></p>
      <button type="submit" class="btn btn-primary btn-block">Confirmar</button>
    </form>
  `;
}

function ligarFormularioManual(container, onDetected) {
  const form = container.querySelector('#scanner-form-manual');
  const input = container.querySelector('#scanner-input-manual');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const codigo = input.value.trim();
    const erroEl = container.querySelector('#scanner-erro-manual');
    erroEl.classList.add('is-hidden');

    if (!codigo) {
      erroEl.textContent = 'Digite um código.';
      erroEl.classList.remove('is-hidden');
      return;
    }

    onDetected(codigo, { manual: true });
  });
}

function mostrarEntradaManual(container, onDetected, mensagemTopo = '') {
  pararCamera();
  container.innerHTML = formularioManualHTML(mensagemTopo);
  ligarFormularioManual(container, onDetected);
}

async function iniciarCamera(container, onDetected) {
  container.innerHTML = areaVideoHTML();

  const video = container.querySelector('#scanner-video');
  container.querySelector('#scanner-btn-manual').addEventListener('click', () => {
    mostrarEntradaManual(container, onDetected);
  });

  try {
    streamAtual = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' },
      audio: false,
    });
  } catch (err) {
    // Permissão negada, câmera em uso por outro app, dispositivo sem
    // câmera, etc. — cai para a entrada manual sem travar o fluxo.
    mostrarEntradaManual(
      container,
      onDetected,
      'Não foi possível acessar a câmera (permissão negada ou indisponível). Digite o código abaixo.'
    );
    return;
  }

  // O overlay pode ter sido fechado enquanto aguardávamos a permissão.
  if (!overlayAtual) {
    pararCamera();
    return;
  }

  video.srcObject = streamAtual;
  await video.play().catch(() => {});

  const detector = new window.BarcodeDetector({ formats: FORMATOS_SUPORTADOS });
  loopAtivo = true;

  const detectar = async () => {
    if (!loopAtivo) {
      return;
    }
    try {
      const codigosDetectados = await detector.detect(video);
      if (loopAtivo && codigosDetectados.length > 0) {
        const codigo = (codigosDetectados[0].rawValue || '').trim();
        if (codigo) {
          loopAtivo = false;
          onDetected(codigo, { manual: false });
          return;
        }
      }
    } catch (err) {
      // Frame ainda não pronto para análise (ex.: vídeo pausando) —
      // ignora e tenta novamente no próximo quadro.
    }
    if (loopAtivo) {
      requestAnimationFrame(detectar);
    }
  };

  requestAnimationFrame(detectar);
}

/**
 * Abre o leitor de código de barras (câmera, com entrada manual como
 * alternativa sempre visível/alcançável).
 * @param {{titulo?: string, onDetected: (codigo: string, info: {manual: boolean}) => void}} opcoes
 */
export function openScanner({ titulo = 'Escanear código de barras', onDetected }) {
  closeScanner();

  const overlay = document.createElement('div');
  overlay.className = 'scanner-overlay';
  overlay.innerHTML = overlayShellHTML(titulo);

  overlay.querySelector('#scanner-btn-fechar').addEventListener('click', closeScanner);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      closeScanner();
    }
  });

  document.body.appendChild(overlay);
  document.body.classList.add('scanner-open');
  overlayAtual = overlay;

  // Etapa 14: tecla Esc fecha o leitor (para a câmera corretamente,
  // já que passa por closeScanner), igual ao botão "✕".
  keydownHandlerScanner = (e) => {
    if (e.key === 'Escape') {
      closeScanner();
    }
  };
  document.addEventListener('keydown', keydownHandlerScanner);

  const container = overlay.querySelector('#scanner-conteudo');

  if (suportaCameraNativa()) {
    iniciarCamera(container, onDetected);
  } else {
    mostrarEntradaManual(
      container,
      onDetected,
      'Este navegador não suporta leitura de código de barras pela câmera. Digite o código abaixo.'
    );
  }
}
