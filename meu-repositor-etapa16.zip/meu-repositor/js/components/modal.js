// js/components/modal.js
// Componente reutilizável de modal/diálogo.
// Uso: openModal({ title, bodyHTML, onMount, onClose })
// onMount(modalBodyEl) roda depois do modal estar no DOM, útil para
// pegar referências de inputs e ligar o submit do formulário.

let currentOverlay = null;
let keydownHandler = null;
let viewportHandler = null;
let focusinHandler = null;

// Ajuste: no celular, ao focar um campo o teclado virtual abre e, em
// boa parte dos Android, a "vh" do CSS não encolhe junto — o teclado
// só cobre a parte de baixo da tela por cima do modal (que fica
// ancorado embaixo). Isso escondia os campos do formulário atrás do
// teclado, e só dava pra ver o que tava sendo digitado depois de
// focar um campo mais abaixo (ex.: "Marca"), que por sorte ficava
// acima do teclado. Corrigido usando window.visualViewport (tamanho
// da área realmente visível, que encolhe com o teclado) para
// redimensionar o overlay do modal e rolar o campo focado pra dentro
// dessa área.
function ajustarAlturaParaTeclado() {
  if (!currentOverlay || !window.visualViewport) {
    return;
  }
  const vv = window.visualViewport;
  currentOverlay.style.height = `${vv.height}px`;
  // Em alguns navegadores o viewport visível também pode deslocar
  // verticalmente (offsetTop) quando o teclado abre.
  currentOverlay.style.transform = vv.offsetTop ? `translateY(${vv.offsetTop}px)` : '';
}

function rolarCampoFocadoParaVisivel(alvo) {
  if (!alvo || !currentOverlay?.contains(alvo)) {
    return;
  }
  // Pequeno atraso: o teclado ainda está abrindo/animando quando o
  // evento de foco dispara, então o scrollIntoView imediato calcularia
  // a posição com o viewport antigo (ainda sem o teclado).
  setTimeout(() => {
    alvo.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }, 150);
}

export function closeModal() {
  if (currentOverlay) {
    currentOverlay.remove();
    currentOverlay = null;
    document.body.classList.remove('modal-open');
  }
  if (keydownHandler) {
    document.removeEventListener('keydown', keydownHandler);
    keydownHandler = null;
  }
  if (viewportHandler && window.visualViewport) {
    window.visualViewport.removeEventListener('resize', viewportHandler);
    window.visualViewport.removeEventListener('scroll', viewportHandler);
    viewportHandler = null;
  }
  if (focusinHandler) {
    document.removeEventListener('focusin', focusinHandler);
    focusinHandler = null;
  }
}

/**
 * @param {{title: string, bodyHTML: string, onMount?: (body: HTMLElement) => void}} options
 */
export function openModal({ title, bodyHTML, onMount }) {
  closeModal();

  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-box" role="dialog" aria-modal="true">
      <div class="modal-header">
        <h3>${title}</h3>
        <button type="button" class="modal-close" aria-label="Fechar">✕</button>
      </div>
      <div class="modal-body"></div>
    </div>
  `;

  const body = overlay.querySelector('.modal-body');
  body.innerHTML = bodyHTML;

  overlay.querySelector('.modal-close').addEventListener('click', closeModal);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      closeModal();
    }
  });

  document.body.appendChild(overlay);
  document.body.classList.add('modal-open');
  currentOverlay = overlay;

  // Etapa 14: tecla Esc fecha o modal, igual ao botão "✕" — comum em
  // diálogos nativos e esperado por quem usa teclado físico (tablet/
  // desktop) mesmo num app pensado mobile-first.
  keydownHandler = (e) => {
    if (e.key === 'Escape') {
      closeModal();
    }
  };
  document.addEventListener('keydown', keydownHandler);

  if (window.visualViewport) {
    viewportHandler = ajustarAlturaParaTeclado;
    window.visualViewport.addEventListener('resize', viewportHandler);
    window.visualViewport.addEventListener('scroll', viewportHandler);
    ajustarAlturaParaTeclado();
  }

  focusinHandler = (e) => {
    if (e.target?.matches?.('input, textarea, select')) {
      rolarCampoFocadoParaVisivel(e.target);
    }
  };
  document.addEventListener('focusin', focusinHandler);

  // Etapa 14: quando o corpo do modal já pede foco automático num
  // campo (atributo `autofocus`, usado nos formulários de novo/editar
  // produto), leva o foco pra lá — o atributo em si não funciona
  // sozinho porque o conteúdo é inserido via innerHTML, então o foco
  // é feito aqui manualmente. Modais sem `autofocus` (ex.: detalhes
  // do produto, histórico) não recebem foco automático em nenhum
  // campo de texto: abrir esses modais não deveria disparar o
  // teclado virtual sozinho, já que muitas vezes é só pra consultar
  // algo. Nesse caso, o foco vai para o botão de fechar — mantém o
  // foco dentro do diálogo (útil pra quem navega por teclado) sem
  // interromper com o teclado virtual.
  requestAnimationFrame(() => {
    const alvo = body.querySelector('[autofocus]') || overlay.querySelector('.modal-close');
    alvo?.focus({ preventScroll: true });
  });

  if (onMount) {
    onMount(body);
  }
}
