// js/components/expiration-card.js
// Componente de exibição de uma validade, com badge de status
// (crítico/atenção/normal/vencido). Implementado na Etapa 8/9.
//
// Usado em dois contextos:
// - Tela Validades (lista geral): mostra o nome do produto, pois reúne
//   validades de vários produtos.
// - Detalhes do produto (dentro do modal de um produto específico):
//   nome do produto omitido, já que está implícito no contexto.

import { escapeHTML } from '../utils/formatters.js';
import { classificarValidade, formatarDataValidade, textoDiasRestantes } from '../utils/dates.js';

const STATUS_LABEL = {
  vencido: 'Vencido',
  critico: 'Crítico',
  atencao: 'Atenção',
  normal: 'Normal',
};

/**
 * Gera o HTML de um card/linha de validade.
 * @param {{id:number, produtoId:number, dataValidade:string}} validade
 * @param {{nomeProduto?: string}} opcoes Quando informado, exibe o nome
 *   do produto e torna a linha clicável (data-action="detalhes") para
 *   abrir os detalhes dele.
 * @returns {string}
 */
export function renderExpirationCardHTML(validade, { nomeProduto = null } = {}) {
  const status = classificarValidade(validade.dataValidade);
  const label = STATUS_LABEL[status];

  return `
    <div class="card expiration-item" data-id="${validade.id}" data-produto-id="${validade.produtoId}">
      <div class="expiration-item-info"${nomeProduto ? ' data-action="detalhes"' : ''}>
        ${nomeProduto ? `<span class="expiration-item-nome">${escapeHTML(nomeProduto)}</span>` : ''}
        <span class="expiration-item-data">
          ${formatarDataValidade(validade.dataValidade)} · ${textoDiasRestantes(validade.dataValidade)}
        </span>
      </div>
      <span class="badge badge-${status}">${label}</span>
      <button type="button" class="btn-icon" data-action="remover-validade" aria-label="Remover validade">🗑️</button>
    </div>
  `;
}
