// js/components/toast.js
// Componente reutilizável de notificação rápida (toast).
// Uso: showToast('Produto salvo!') ou showToast('Erro ao salvar', 'error')

let container = null;

function getContainer() {
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    // Etapa 14: leitores de tela anunciam o toast assim que ele
    // aparece, sem precisar que o foco esteja nele (role="status" já
    // implica aria-live="polite", mas declarar os dois deixa
    // explícito e cobre navegadores mais antigos).
    container.setAttribute('role', 'status');
    container.setAttribute('aria-live', 'polite');
    document.body.appendChild(container);
  }
  return container;
}

/**
 * Mostra uma notificação rápida na tela.
 * @param {string} message
 * @param {'success'|'error'} type
 */
export function showToast(message, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;

  const holder = getContainer();
  holder.appendChild(el);

  // Força reflow para a transição de entrada funcionar.
  requestAnimationFrame(() => el.classList.add('is-visible'));

  setTimeout(() => {
    el.classList.remove('is-visible');
    setTimeout(() => el.remove(), 300);
  }, 2500);
}
