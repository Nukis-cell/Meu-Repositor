// js/db/expirations.js
// Operações de CRUD para a entidade Validade.
//
// Validade: { id, produtoId, codigoId, dataValidade, criadoEm, atualizadoEm, status }
// codigoId é opcional. Várias validades por produto são permitidas
// (uma nova NÃO substitui uma existente). Sem controle de quantidade.
// status: 'ativo' | 'vencido' (cálculo de dias/cor fica para a Etapa 8/9).

import { STORES } from '../config/config.js';
import { dbAdd, dbPut, dbGet, dbGetAll, dbGetAllByIndex, dbDelete } from './database.js';

/**
 * Cadastra uma nova validade para um produto.
 * @param {{produtoId: number, dataValidade: string, codigoId?: string}} dados
 *   dataValidade no formato ISO (YYYY-MM-DD).
 */
export async function cadastrarValidade({ produtoId, dataValidade, codigoId = null }) {
  if (!produtoId) {
    throw new Error('produtoId é obrigatório para cadastrar uma validade.');
  }
  if (!dataValidade) {
    throw new Error('dataValidade é obrigatória.');
  }

  const agora = new Date().toISOString();
  const registro = {
    produtoId,
    codigoId,
    dataValidade,
    criadoEm: agora,
    atualizadoEm: agora,
    status: 'ativo',
  };

  const id = await dbAdd(STORES.VALIDADES, registro);
  return { ...registro, id };
}

/** Lista todas as validades de um produto específico (não substituem umas às outras). */
export async function listarValidadesDoProduto(produtoId) {
  return dbGetAllByIndex(STORES.VALIDADES, 'produtoId', produtoId);
}

/** Lista todas as validades cadastradas (todos os produtos). */
export async function listarTodasValidades() {
  return dbGetAll(STORES.VALIDADES);
}

/** Busca uma validade pelo id. */
export async function obterValidade(id) {
  return dbGet(STORES.VALIDADES, id);
}

/** Atualiza o status de uma validade (ex.: marcar como 'vencido'). */
export async function atualizarStatusValidade(id, status) {
  const validade = await obterValidade(id);
  if (!validade) {
    throw new Error(`Validade ${id} não encontrada.`);
  }

  const atualizada = {
    ...validade,
    status,
    atualizadoEm: new Date().toISOString(),
  };

  await dbPut(STORES.VALIDADES, atualizada);
  return atualizada;
}

/** Remove um registro de validade. */
export async function removerValidade(id) {
  return dbDelete(STORES.VALIDADES, id);
}
