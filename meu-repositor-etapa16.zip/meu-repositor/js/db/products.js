// js/db/products.js
// Operações de CRUD para a entidade Produto.
//
// Produto: { id, nome, marca, categoria, criadoEm, atualizadoEm }
// O id é interno e independente do código de barras (ver barcodes.js).

import { STORES } from '../config/config.js';
import { dbAdd, dbPut, dbGet, dbGetAll, dbDelete } from './database.js';

/**
 * Cria um novo produto.
 * @param {{nome: string, marca?: string, categoria?: string}} dados
 * @returns {Promise<number>} id do produto criado
 */
export async function criarProduto({ nome, marca = '', categoria = '' }) {
  if (!nome || !nome.trim()) {
    throw new Error('O nome do produto é obrigatório.');
  }

  const agora = new Date().toISOString();
  const produto = {
    nome: nome.trim(),
    marca: marca.trim(),
    categoria: categoria.trim(),
    criadoEm: agora,
    atualizadoEm: agora,
  };

  return dbAdd(STORES.PRODUTOS, produto);
}

/** Busca um produto pelo id interno. */
export async function obterProduto(id) {
  return dbGet(STORES.PRODUTOS, id);
}

/** Retorna todos os produtos cadastrados. */
export async function listarProdutos() {
  return dbGetAll(STORES.PRODUTOS);
}

/**
 * Procura um produto já cadastrado com o mesmo nome e a mesma marca
 * (comparação sem diferenciar maiúsculas/minúsculas e ignorando
 * espaços nas pontas), para evitar cadastro duplicado do mesmo
 * produto por engano. Retorna `null` se não houver nome informado ou
 * se nenhum produto bater.
 * @param {string} nome
 * @param {string} [marca]
 * @returns {Promise<object|null>}
 */
export async function buscarProdutoDuplicado(nome, marca = '') {
  const nomeNormalizado = String(nome || '').trim().toLowerCase();
  if (!nomeNormalizado) {
    return null;
  }
  const marcaNormalizada = String(marca || '').trim().toLowerCase();

  const produtos = await listarProdutos();
  return (
    produtos.find(
      (p) =>
        p.nome.trim().toLowerCase() === nomeNormalizado &&
        (p.marca || '').trim().toLowerCase() === marcaNormalizada
    ) || null
  );
}

/**
 * Atualiza campos de um produto existente.
 * @param {number} id
 * @param {{nome?: string, marca?: string, categoria?: string}} alteracoes
 */
export async function atualizarProduto(id, alteracoes) {
  const produto = await obterProduto(id);
  if (!produto) {
    throw new Error(`Produto ${id} não encontrado.`);
  }

  const atualizado = {
    ...produto,
    ...alteracoes,
    id: produto.id,
    atualizadoEm: new Date().toISOString(),
  };

  await dbPut(STORES.PRODUTOS, atualizado);
  return atualizado;
}

/**
 * Remove um produto pelo id.
 * Observação: a remoção de códigos de barras, reposições e validades
 * associadas será tratada nas telas correspondentes (Etapas 4/5/7/8),
 * para permitir confirmação explícita do usuário antes de apagar em
 * cascata.
 */
export async function removerProduto(id) {
  return dbDelete(STORES.PRODUTOS, id);
}
