// js/db/backup.js
// Exportação e restauração completa dos dados do app (Etapa 12).
//
// O backup é um objeto (salvo como arquivo .json por quem chama este
// módulo) contendo todos os registros de todas as object stores do
// IndexedDB, mais alguns metadados (nome do app, versão do banco, data
// de criação) para permitir uma verificação básica antes de restaurar.
//
// Formato do arquivo de backup:
// {
//   app: 'Meu Repositor',
//   dbVersion: 2,
//   criadoEm: '2026-09-11T12:00:00.000Z',
//   dados: {
//     produtos: [...],
//     codigosBarras: [...],
//     reposicao: [...],
//     validades: [...],
//     historico: [...],
//   }
// }

import { APP_NAME, DB_VERSION, STORES } from '../config/config.js';
import { dbGetAll, dbClear, dbPut } from './database.js';

// Todas as stores que fazem parte do backup, na ordem em que são
// exportadas/restauradas (a ordem não afeta o resultado, já que o
// IndexedDB não impõe integridade referencial entre stores — mas manter
// uma ordem fixa deixa o arquivo gerado mais fácil de ler).
const STORES_DO_BACKUP = [
  STORES.PRODUTOS,
  STORES.CODIGOS_BARRAS,
  STORES.REPOSICAO,
  STORES.VALIDADES,
  STORES.HISTORICO,
];

/**
 * Monta o objeto de backup com todos os dados atuais do banco.
 * @returns {Promise<object>}
 */
export async function gerarBackup() {
  const dados = {};
  for (const storeName of STORES_DO_BACKUP) {
    dados[storeName] = await dbGetAll(storeName);
  }

  return {
    app: APP_NAME,
    dbVersion: DB_VERSION,
    criadoEm: new Date().toISOString(),
    dados,
  };
}

/**
 * Verifica, de forma básica, se um objeto parece um backup válido deste
 * app. Não garante integridade total dos dados — serve para recusar
 * logo de cara um arquivo claramente errado (ex.: um JSON qualquer
 * escolhido por engano).
 * @param {any} obj
 */
export function pareceBackupValido(obj) {
  return Boolean(
    obj &&
      typeof obj === 'object' &&
      obj.dados &&
      typeof obj.dados === 'object' &&
      STORES_DO_BACKUP.some((storeName) => Array.isArray(obj.dados[storeName]))
  );
}

/**
 * Restaura o banco a partir de um objeto de backup: apaga todos os
 * dados atuais de cada store conhecida e insere os registros do
 * backup no lugar (substituição completa, não uma mesclagem).
 *
 * Stores ausentes no arquivo (ex.: um backup feito antes da Etapa 11,
 * sem histórico) são apenas limpas, sem gerar erro — permite restaurar
 * backups mais antigos sem quebrar.
 *
 * @param {object} backup
 */
export async function restaurarBackup(backup) {
  if (!pareceBackupValido(backup)) {
    throw new Error('Arquivo de backup inválido ou corrompido.');
  }

  for (const storeName of STORES_DO_BACKUP) {
    await dbClear(storeName);
    const registros = Array.isArray(backup.dados[storeName]) ? backup.dados[storeName] : [];
    for (const registro of registros) {
      // dbPut (não dbAdd) preserva o id/chave original de cada registro
      // do backup, em vez de gerar um novo — importante para manter as
      // referências entre entidades (ex.: validade.produtoId) coerentes.
      await dbPut(storeName, registro);
    }
  }
}
