// js/db/replenishment.js
// Operações de CRUD para a entidade Reposição.
//
// Reposição: { id, produtoId, criadoEm, concluidoEm, faltaEm, status }
// status: 'pendente' | 'concluido' | 'falta'
// Sem controle de quantidade. Não deve haver duplicata de item
// pendente para o mesmo produto.
//
// Ajuste pós-Etapa 12 (item 4): status 'falta' cobre o caso de um
// item pendente que não pôde ser reposto porque não havia mais do
// produto no estoque — tira o item da lista de pendentes sem marcar
// como "concluído" (que implicaria que a reposição foi feita).

import { STORES } from '../config/config.js';
import { dbAdd, dbPut, dbGet, dbGetAll, dbGetAllByIndex } from './database.js';

/**
 * Adiciona um produto à lista de reposição.
 * Se já existir um registro pendente para o mesmo produto, retorna o
 * registro existente em vez de criar duplicata.
 * @param {number} produtoId
 */
export async function adicionarReposicao(produtoId) {
  const pendentes = await dbGetAllByIndex(STORES.REPOSICAO, 'produtoId', produtoId);
  const jaPendente = pendentes.find((item) => item.status === 'pendente');
  if (jaPendente) {
    return jaPendente;
  }

  const registro = {
    produtoId,
    criadoEm: new Date().toISOString(),
    concluidoEm: null,
    faltaEm: null,
    status: 'pendente',
  };

  const id = await dbAdd(STORES.REPOSICAO, registro);
  return { ...registro, id };
}

/** Lista todos os itens de reposição pendentes. */
export async function listarPendentes() {
  return dbGetAllByIndex(STORES.REPOSICAO, 'status', 'pendente');
}

/**
 * Retorna o item de reposição pendente de um produto, ou null se ele
 * não estiver marcado para repor no momento.
 * @param {number} produtoId
 */
export async function obterPendentePorProduto(produtoId) {
  const pendentes = await dbGetAllByIndex(STORES.REPOSICAO, 'produtoId', produtoId);
  return pendentes.find((item) => item.status === 'pendente') || null;
}

/** Lista todos os itens de reposição já concluídos (histórico). */
export async function listarConcluidos() {
  return dbGetAllByIndex(STORES.REPOSICAO, 'status', 'concluido');
}

/** Lista todos os itens marcados como "falta" (não havia no estoque para repor). */
export async function listarFalta() {
  return dbGetAllByIndex(STORES.REPOSICAO, 'status', 'falta');
}

/** Lista todos os registros de reposição (pendentes + concluídos + falta). */
export async function listarTodasReposicoes() {
  return dbGetAll(STORES.REPOSICAO);
}

/** Marca um item de reposição como concluído. */
export async function concluirReposicao(id) {
  const item = await dbGet(STORES.REPOSICAO, id);
  if (!item) {
    throw new Error(`Item de reposição ${id} não encontrado.`);
  }

  const atualizado = {
    ...item,
    status: 'concluido',
    concluidoEm: new Date().toISOString(),
  };

  await dbPut(STORES.REPOSICAO, atualizado);
  return atualizado;
}

/**
 * Marca um item de reposição pendente como "falta" — tira da lista de
 * pendentes sem contar como reposição feita (ex.: não tinha mais o
 * produto no estoque).
 */
export async function marcarFalta(id) {
  const item = await dbGet(STORES.REPOSICAO, id);
  if (!item) {
    throw new Error(`Item de reposição ${id} não encontrado.`);
  }

  const atualizado = {
    ...item,
    status: 'falta',
    faltaEm: new Date().toISOString(),
  };

  await dbPut(STORES.REPOSICAO, atualizado);
  return atualizado;
}

/**
 * Volta um item marcado como "falta" para pendente (ex.: o estoque
 * chegou de novo). Reaproveita o mesmo registro em vez de criar um
 * novo, então não gera duplicata.
 */
export async function reativarReposicao(id) {
  const item = await dbGet(STORES.REPOSICAO, id);
  if (!item) {
    throw new Error(`Item de reposição ${id} não encontrado.`);
  }

  const atualizado = {
    ...item,
    status: 'pendente',
    criadoEm: new Date().toISOString(),
    concluidoEm: null,
    faltaEm: null,
  };

  await dbPut(STORES.REPOSICAO, atualizado);
  return atualizado;
}
