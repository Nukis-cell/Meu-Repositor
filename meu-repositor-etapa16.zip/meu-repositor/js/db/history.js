// js/db/history.js
// Operações para a entidade Histórico (Etapa 11).
//
// Historico: { id, tipo, descricao, produtoId, criadoEm }
// A descrição já é gerada por quem chama `registrarEvento` (contendo,
// por exemplo, o nome do produto) — o histórico não referencia dados
// que podem ser alterados ou excluídos depois, para continuar fazendo
// sentido mesmo que o produto original não exista mais.

import { STORES } from '../config/config.js';
import { dbAdd, dbGetAll, dbClear } from './database.js';

/**
 * Registra um evento no histórico.
 * @param {{tipo: string, descricao: string, produtoId?: number|null}} evento
 */
export async function registrarEvento({ tipo, descricao, produtoId = null }) {
  if (!tipo || !descricao) {
    throw new Error('tipo e descricao são obrigatórios para registrar um evento.');
  }

  const registro = {
    tipo,
    descricao,
    produtoId,
    criadoEm: new Date().toISOString(),
  };

  const id = await dbAdd(STORES.HISTORICO, registro);
  return { ...registro, id };
}

/** Lista todo o histórico registrado (mais recente por último; quem exibe decide a ordem). */
export async function listarHistorico() {
  return dbGetAll(STORES.HISTORICO);
}

/** Apaga todo o histórico (usado pelo botão "Limpar histórico" em Configurações). */
export async function limparHistorico() {
  return dbClear(STORES.HISTORICO);
}
