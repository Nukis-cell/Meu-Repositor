// js/db/barcodes.js
// Operações de CRUD para a entidade Código de Barras.
//
// CódigoDeBarras: { codigo, produtoId }
// O próprio código é a chave primária (naturalmente único). Um código
// nunca pode apontar para dois produtos ao mesmo tempo.

import { STORES } from '../config/config.js';
import { dbAdd, dbGet, dbGetAllByIndex, dbDelete } from './database.js';

/**
 * Associa um código de barras a um produto.
 * Lança erro se o código já estiver associado a outro produto.
 * @param {string} codigo
 * @param {number} produtoId
 */
export async function associarCodigo(codigo, produtoId) {
  const codigoLimpo = String(codigo).trim();
  if (!codigoLimpo) {
    throw new Error('Código de barras vazio.');
  }

  const existente = await dbGet(STORES.CODIGOS_BARRAS, codigoLimpo);
  if (existente && existente.produtoId !== produtoId) {
    throw new Error(
      `O código ${codigoLimpo} já está associado a outro produto (id ${existente.produtoId}).`
    );
  }
  if (existente && existente.produtoId === produtoId) {
    // Já associado a este mesmo produto — não faz nada.
    return existente;
  }

  const registro = { codigo: codigoLimpo, produtoId };
  await dbAdd(STORES.CODIGOS_BARRAS, registro);
  return registro;
}

/** Busca a associação de um código de barras (undefined se não cadastrado). */
export async function buscarCodigo(codigo) {
  return dbGet(STORES.CODIGOS_BARRAS, String(codigo).trim());
}

/** Lista todos os códigos de barras associados a um produto. */
export async function listarCodigosDoProduto(produtoId) {
  return dbGetAllByIndex(STORES.CODIGOS_BARRAS, 'produtoId', produtoId);
}

/** Remove a associação de um código de barras. */
export async function removerCodigo(codigo) {
  return dbDelete(STORES.CODIGOS_BARRAS, String(codigo).trim());
}
