// js/db/database.js
// Camada central de acesso ao IndexedDB: abertura da conexão,
// criação/upgrade da estrutura (object stores + índices), e
// funções genéricas de CRUD usadas pelos demais módulos de js/db/.
//
// Nenhum outro módulo deve chamar a API do IndexedDB diretamente —
// tudo passa por este arquivo.

import { DB_NAME, DB_VERSION, STORES } from '../config/config.js';
import { registrarErro } from '../utils/errorlog.js';

let dbPromise = null;

/**
 * Abre (ou cria/atualiza) o banco de dados. A conexão é reaproveitada
 * entre chamadas (singleton simples via dbPromise).
 * @returns {Promise<IDBDatabase>}
 */
export function openDatabase() {
  if (dbPromise) {
    return dbPromise;
  }

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      upgradeSchema(db, event.oldVersion, event.newVersion);
    };

    request.onsuccess = (event) => {
      resolve(event.target.result);
    };

    request.onerror = (event) => {
      dbPromise = null;
      const erro = event.target.error;
      // Etapa 13: registrado mesmo antes de qualquer tela existir,
      // porque é justamente o cenário em que o app inteiro fica sem
      // dados — importante que fique registrado em algum lugar.
      registrarErro({
        origem: 'indexeddb',
        mensagem: erro?.message || 'Erro ao abrir o banco de dados.',
        stack: erro?.stack || '',
        contexto: 'abertura do banco',
      });
      reject(erro);
    };

    request.onblocked = () => {
      console.warn('Abertura do banco bloqueada por outra aba/conexão aberta.');
    };
  });

  return dbPromise;
}

/**
 * Cria/atualiza a estrutura do banco (object stores e índices).
 * Ponto único de migração de schema — se DB_VERSION for incrementado
 * no futuro, novas migrações devem ser adicionadas aqui, verificando
 * oldVersion para não recriar o que já existe.
 */
function upgradeSchema(db, oldVersion) {
  // v1: estrutura inicial (Etapa 3)
  if (oldVersion < 1) {
    // Produto: id interno próprio (autoIncrement), independente do
    // código de barras.
    const produtos = db.createObjectStore(STORES.PRODUTOS, {
      keyPath: 'id',
      autoIncrement: true,
    });
    produtos.createIndex('nome', 'nome', { unique: false });
    produtos.createIndex('categoria', 'categoria', { unique: false });

    // Código de Barras: o próprio código é a chave primária (é
    // naturalmente único), apontando para um produtoId.
    const codigos = db.createObjectStore(STORES.CODIGOS_BARRAS, {
      keyPath: 'codigo',
    });
    codigos.createIndex('produtoId', 'produtoId', { unique: false });

    // Reposição: independente de validade; sem quantidade.
    const reposicao = db.createObjectStore(STORES.REPOSICAO, {
      keyPath: 'id',
      autoIncrement: true,
    });
    reposicao.createIndex('produtoId', 'produtoId', { unique: false });
    reposicao.createIndex('status', 'status', { unique: false });

    // Validade: várias por produto; codigoId opcional; sem quantidade.
    const validades = db.createObjectStore(STORES.VALIDADES, {
      keyPath: 'id',
      autoIncrement: true,
    });
    validades.createIndex('produtoId', 'produtoId', { unique: false });
    validades.createIndex('status', 'status', { unique: false });
    validades.createIndex('dataValidade', 'dataValidade', { unique: false });
  }

  // v2: Histórico (Etapa 11) — registro cronológico de eventos
  // (produto criado/editado/excluído, código adicionado/removido,
  // reposição marcada/concluída, validade cadastrada/removida).
  // A descrição já vem pronta (com o nome do produto) no momento do
  // registro, porque o produto pode ser excluído depois — o
  // histórico não deve depender de reconsultar dados que podem não
  // existir mais.
  if (oldVersion < 2) {
    const historico = db.createObjectStore(STORES.HISTORICO, {
      keyPath: 'id',
      autoIncrement: true,
    });
    historico.createIndex('criadoEm', 'criadoEm', { unique: false });
    historico.createIndex('tipo', 'tipo', { unique: false });
  }
}

/**
 * Abre uma transação na store indicada e devolve a própria store,
 * já dentro da transação, para o chamador operar sobre ela.
 * @param {string} storeName
 * @param {'readonly'|'readwrite'} mode
 */
export async function getStore(storeName, mode = 'readonly') {
  const db = await openDatabase();
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
}

/** Envolve um IDBRequest em uma Promise. */
export function promisifyRequest(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Executa uma operação de banco, registrando no log de diagnóstico
 * (Etapa 13) qualquer erro que aconteça — sem mudar o comportamento
 * para quem chama: o erro original continua sendo relançado
 * normalmente, para os `catch` já existentes em `js/db/*` e
 * `js/pages/*` continuarem funcionando exatamente como antes. Isso
 * garante que TODO erro de IndexedDB, de qualquer módulo, fique
 * registrado num único lugar para a tela de Diagnóstico — mesmo que
 * quem chamou só tenha dado `console.error` ou nem tenha `catch`.
 * @param {string} contexto Descrição curta da operação (ex.: 'add em "produtos"').
 * @param {() => Promise<any>} operacao
 */
async function executarComRegistroDeErro(contexto, operacao) {
  try {
    return await operacao();
  } catch (err) {
    registrarErro({
      origem: 'indexeddb',
      mensagem: err?.message || String(err),
      stack: err?.stack || '',
      contexto,
    });
    throw err;
  }
}

/** Adiciona um registro novo. Rejeita se a chave já existir (add, não put). */
export async function dbAdd(storeName, value) {
  return executarComRegistroDeErro(`add em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readwrite');
    return promisifyRequest(store.add(value));
  });
}

/** Cria ou substitui um registro (usa a keyPath do próprio value). */
export async function dbPut(storeName, value) {
  return executarComRegistroDeErro(`put em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readwrite');
    return promisifyRequest(store.put(value));
  });
}

/** Busca um registro pela chave primária. */
export async function dbGet(storeName, key) {
  return executarComRegistroDeErro(`get em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readonly');
    return promisifyRequest(store.get(key));
  });
}

/** Retorna todos os registros de uma store. */
export async function dbGetAll(storeName) {
  return executarComRegistroDeErro(`getAll em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readonly');
    return promisifyRequest(store.getAll());
  });
}

/** Retorna todos os registros cujo índice bate com o valor informado. */
export async function dbGetAllByIndex(storeName, indexName, value) {
  return executarComRegistroDeErro(`getAllByIndex "${indexName}" em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readonly');
    const index = store.index(indexName);
    return promisifyRequest(index.getAll(value));
  });
}

/** Remove um registro pela chave primária. */
export async function dbDelete(storeName, key) {
  return executarComRegistroDeErro(`delete em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readwrite');
    return promisifyRequest(store.delete(key));
  });
}

/** Remove todos os registros de uma store (usado por limpar histórico e restaurar backup). */
export async function dbClear(storeName) {
  return executarComRegistroDeErro(`clear em "${storeName}"`, async () => {
    const store = await getStore(storeName, 'readwrite');
    return promisifyRequest(store.clear());
  });
}
