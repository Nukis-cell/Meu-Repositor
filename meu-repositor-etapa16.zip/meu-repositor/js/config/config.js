// js/config/config.js
// Configurações globais do aplicativo.

export const APP_NAME = 'Meu Repositor';

// Nome e versão do banco IndexedDB.
// Ao mudar a estrutura das object stores no futuro, incrementar
// DB_VERSION e tratar a migração em js/db/database.js.
export const DB_NAME = 'meu-repositor-db';
export const DB_VERSION = 2;

// Nomes das object stores (usados em toda a camada js/db).
export const STORES = {
  PRODUTOS: 'produtos',
  CODIGOS_BARRAS: 'codigosBarras',
  REPOSICAO: 'reposicao',
  VALIDADES: 'validades',
  HISTORICO: 'historico',
};

// Limites de classificação de validade (em dias), usados a partir da Etapa 8/9.
export const VALIDADE_LIMITES = {
  CRITICO_DIAS: 7,
  ATENCAO_DIAS: 30,
};
