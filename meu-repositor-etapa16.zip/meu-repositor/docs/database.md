# Modelo de Dados — Meu Repositor

> Este documento descreve o modelo conceitual definido na Etapa 1.
> A implementação real das object stores do IndexedDB será feita na
> Etapa 3.

## Regra fundamental

O **código de barras não é o identificador principal do produto**. Um
produto tem seu próprio `id` interno; códigos de barras são registros
separados que apontam para esse `id`.

## Entidade: Produto

| Campo        | Tipo   | Observações                        |
|--------------|--------|-------------------------------------|
| id           | string/number | Identificador interno, independente do código de barras |
| nome         | string | |
| marca        | string | |
| categoria    | string | |
| criadoEm     | data   | |
| atualizadoEm | data   | |

## Entidade: Código de Barras

| Campo      | Tipo   | Observações |
|------------|--------|-------------|
| codigo     | string | O próprio código de barras (chave de busca) |
| produtoId  | string/number | Referência ao produto |

Regras:
- Um produto pode ter **vários** códigos de barras associados.
- Um código de barras **não pode** apontar para dois produtos ao mesmo
  tempo (verificação de conflito obrigatória antes de salvar).

## Entidade: Reposição

| Campo       | Tipo   | Observações |
|-------------|--------|-------------|
| id          | string/number | |
| produtoId   | string/number | |
| criadoEm    | data | |
| concluidoEm | data | nulo até ser concluído |
| status      | string | ex.: `pendente` / `concluido` |

Regras:
- **Sem controle obrigatório de quantidade.**
- Se o produto já estiver pendente na lista, escanear novamente **não**
  cria duplicata.

## Entidade: Validade

| Campo        | Tipo   | Observações |
|--------------|--------|-------------|
| id           | string/number | |
| produtoId    | string/number | |
| codigoId     | string/number (opcional) | referência opcional ao código escaneado |
| dataValidade | data | |
| criadoEm     | data | |
| atualizadoEm | data | |
| status       | string | ex.: `ativo` / `vencido` |

Regras:
- Um produto pode ter **várias validades simultâneas** — cada uma é um
  registro independente; uma nova validade **não substitui** uma
  existente.
- **Sem controle obrigatório de quantidade.**
- Classificação por proximidade do vencimento (limites configuráveis em
  `js/config/config.js`):
  - 🔴 Crítico: até 7 dias
  - 🟡 Atenção: 8 a 30 dias
  - 🟢 Normal: mais de 30 dias
  - Vencido: indicação própria

## Relacionamentos (resumo)

```
Produto (1) ──< Código de Barras (N)
Produto (1) ──< Reposição (N)
Produto (1) ──< Validade (N) ──> Código de Barras (0..1, opcional)
```

## Versionamento

O banco terá uma versão numérica (`DB_VERSION`), definida em
`js/config/config.js`, para permitir migrações seguras de schema em
etapas futuras, caso a estrutura acima precise mudar.

## Backup (Etapa 12)

O backup é um arquivo `.json` com o conteúdo bruto de todas as object
stores, gerado/restaurado por `js/db/backup.js`:

```json
{
  "app": "Meu Repositor",
  "dbVersion": 2,
  "criadoEm": "2026-09-11T12:00:00.000Z",
  "dados": {
    "produtos": [ /* registros da store produtos */ ],
    "codigosBarras": [ /* registros da store codigosBarras */ ],
    "reposicao": [ /* registros da store reposicao */ ],
    "validades": [ /* registros da store validades */ ],
    "historico": [ /* registros da store historico */ ]
  }
}
```

Regras:
- **Restaurar substitui, não mescla**: cada store é apagada por
  completo antes de inserir os registros do arquivo.
- Os registros são inseridos com `put` (não `add`), preservando o `id`
  original de cada um — essencial para manter válidas as referências
  entre entidades (ex.: `validade.produtoId` continuar apontando para
  o produto certo depois de restaurar).
- Um backup de uma etapa anterior (sem alguma store, ex.: sem
  `historico`) ainda pode ser restaurado: a store ausente no arquivo é
  apenas limpa, sem erro.
