# Changelog — Meu Repositor

## Etapa 1 — Planejamento técnico + estrutura inicial

- Especificação do projeto analisada e arquitetura confirmada
  (ver `architecture.md`).
- Estrutura de pastas criada (`assets/`, `css/`, `js/db`, `js/pages`,
  `js/components`, `js/utils`, `js/config`, `docs/`).
- Arquivos-base criados como esqueletos comentados (sem lógica de
  negócio ainda): `index.html`, `manifest.json`, `sw.js`, `js/app.js`,
  todos os arquivos de `css/` e todos os módulos de `js/db`, `js/pages`,
  `js/components`, `js/utils`, `js/config`.
- Documentação inicial criada: `README.md`, `docs/architecture.md`,
  `docs/database.md`, `docs/changelog.md` (este arquivo).
- Nenhuma funcionalidade das próximas etapas foi implementada.

### Próxima etapa planejada

Etapa 2 — PWA básico + layout inicial + navegação (manifest completo,
ícones, Service Worker com estratégia de cache, header/nav/telas de
verdade no HTML/CSS).

## Etapa 2 — PWA básico + layout inicial + navegação

- `manifest.json` finalizado, com ícones reais (placeholder "MR") em
  `assets/icons/icon-192.png` e `icon-512.png`.
- `sw.js` implementado com estratégia de cache do app shell
  (cache-first com atualização em segundo plano) e limpeza de caches
  antigos na ativação.
- `index.html` com layout real: header, 5 telas (Início, Reposição,
  Validades, Produtos, Configurações) e navegação inferior fixa com
  ícones e rótulos.
- CSS real implementado nos 4 arquivos (`main.css`, `layout.css`,
  `components.css`, `responsive.css`): variáveis de cores/espaçamento,
  botões grandes, cards de resumo, badges de status de validade
  (prontos para a Etapa 8), responsividade básica para tablet/desktop.
- `js/app.js` implementado: registro do Service Worker e navegação
  entre telas (mostrar/ocultar seção + destacar item ativo na nav +
  atualizar título do header).
- Conteúdo das 5 telas ainda é placeholder (texto indicando em qual
  etapa cada funcionalidade será implementada) — nenhuma lógica de
  negócio, nenhum acesso ao IndexedDB ainda.

### Próxima etapa planejada

Etapa 3 — IndexedDB + modelo de dados (implementação real de
`js/db/database.js` e das object stores de Produto, Código de Barras,
Reposição e Validade).

## Etapa 3 — IndexedDB + modelo de dados

- `js/config/config.js`: adicionados `DB_NAME`, `DB_VERSION` e `STORES`
  (nomes das object stores).
- `js/db/database.js`: implementado de fato —
  - `openDatabase()` abre/cria o banco e reaproveita a conexão;
  - criação das 4 object stores na v1: `produtos` (id autoIncrement),
    `codigosBarras` (chave = o próprio código), `reposicao` (id
    autoIncrement) e `validades` (id autoIncrement), com os índices
    necessários (`produtoId`, `status`, `dataValidade`, etc.);
  - funções genéricas reutilizáveis (`dbAdd`, `dbPut`, `dbGet`,
    `dbGetAll`, `dbGetAllByIndex`, `dbDelete`) usadas por todos os
    módulos de entidade.
- `js/db/products.js`: `criarProduto`, `obterProduto`, `listarProdutos`,
  `atualizarProduto`, `removerProduto`.
- `js/db/barcodes.js`: `associarCodigo` (com verificação de conflito —
  um código não pode apontar para dois produtos), `buscarCodigo`,
  `listarCodigosDoProduto`, `removerCodigo`.
- `js/db/replenishment.js`: `adicionarReposicao` (sem duplicata se já
  pendente), `listarPendentes`, `listarConcluidos`,
  `listarTodasReposicoes`, `concluirReposicao`.
- `js/db/expirations.js`: `cadastrarValidade` (várias por produto,
  `codigoId` opcional), `listarValidadesDoProduto`,
  `listarTodasValidades`, `obterValidade`, `atualizarStatusValidade`,
  `removerValidade`.
- Nenhuma tela usa essas funções ainda — a UI de cada uma será
  conectada nas Etapas 4, 5, 7 e 8, conforme a ordem combinada.

### Verificação

Como o ambiente de desenvolvimento não tem um navegador disponível para
teste manual automatizado, a camada de banco foi testada com uma
implementação de IndexedDB simulada (Node + `fake-indexeddb`), cobrindo
os cenários de teste da especificação: produto com vários códigos,
código desconhecido, código duplicado (deve gerar erro), produto na
reposição sem duplicata, produto concluído, produto com várias
validades, validade vencida, validade com e sem código associado,
atualização de produto e validação de nome obrigatório. Todas as 16
verificações passaram. Ainda assim, recomenda-se um teste manual no
navegador (passo a passo abaixo) para confirmar no ambiente real.

### Próxima etapa planejada

Etapa 4 — Cadastro de produtos (tela de Produtos usando
`js/db/products.js`).

## Etapa 4 — Cadastro de produtos

- `js/pages/products.js` implementado: lista produtos cadastrados,
  abre modal para criar novo produto (nome obrigatório, marca e
  categoria opcionais), edita produto existente e exclui (com
  confirmação explícita antes de apagar).
- `js/components/modal.js`: componente genérico de modal/diálogo
  reutilizável (usado pelo formulário de produto e reaproveitável nas
  próximas telas).
- `js/components/toast.js`: componente genérico de notificação rápida
  (usado para confirmar "Produto cadastrado.", "Produto atualizado.",
  "Produto excluído.").
- `js/components/product-card.js`: renderização do card de produto na
  lista (nome, marca/categoria, botões editar/excluir).
- `index.html`: tela de Produtos agora tem botão "+ Novo produto" e o
  container da lista.
- `css/components.css`: estilos de formulário, modal, toast e card de
  produto.
- `js/app.js`: inicializa a tela de Produtos ao carregar o app.
- Gerenciamento de múltiplos códigos de barras por produto continua
  como placeholder — é o escopo da Etapa 5.

### Verificação

Testado com jsdom + IndexedDB simulado, simulando cliques reais do
usuário: abrir modal, cadastrar produto, tentar cadastrar sem nome
(deve mostrar erro e manter modal aberto), editar produto existente,
excluir produto, e conferir que a lista volta ao estado vazio. 11 de
11 verificações passaram. Sintaxe de todo o JS e estrutura do HTML
também validadas.

### Próxima etapa planejada

Etapa 5 — Cadastro e gerenciamento de múltiplos códigos de barras por
produto (tela de detalhes do produto).

## Etapa 5 — Múltiplos códigos de barras por produto

- Tela de **detalhes do produto** (modal), acessível pelo novo botão
  🔗 no card ou tocando no nome/detalhes do produto na lista.
- Lista todos os códigos de barras já associados ao produto.
- Formulário para **adicionar novo código** (entrada manual — o
  leitor por câmera é a Etapa 6), com validação de campo vazio.
- **Verificação de conflito**: se o código já pertencer a outro
  produto, é exibida uma mensagem clara com o nome do produto
  conflitante (ex.: `Este código já está associado a "Biscoito
  Chocolate 120g".`), sem permitir o cadastro duplicado.
- **Remoção de código**, com confirmação explícita antes de apagar.
- `js/utils/formatters.js`: `escapeHTML` movido para cá (utilitário
  compartilhado entre `product-card.js` e `products.js`).

### Verificação

Testado com jsdom + IndexedDB simulado, cobrindo os cenários da
especificação: produto com vários códigos, código vazio (bloqueado),
código duplicado em outro produto (bloqueado com mensagem clara),
código próprio adicionado com sucesso, e remoção de código. 10 de 10
verificações passaram. As suítes de teste das Etapas 3 e 4 foram
reexecutadas e continuam passando (27 verificações), confirmando que
nada foi quebrado.

### Próxima etapa planejada

Etapa 6 — Leitor de código de barras (câmera) + entrada manual
integrada ao fluxo de escaneamento.

## Etapa 6 — Leitor de código de barras (câmera) + entrada manual

- `js/components/barcode-scanner.js` implementado: componente
  reutilizável `openScanner({ titulo, onDetected })` /
  `closeScanner()`.
  - Usa a API nativa `BarcodeDetector` (quando disponível) com
    `getUserMedia` (câmera traseira, `facingMode: 'environment'`)
    para ler os formatos mais comuns de varejo (EAN-13, EAN-8,
    UPC-A, UPC-E, Code128, Code39, ITF, Codabar).
  - **Entrada manual sempre disponível**: botão "⌨️ Digitar código
    manualmente" visível junto da câmera, e usada automaticamente
    como alternativa quando o navegador não suporta a API, quando a
    permissão de câmera é negada, ou quando a câmera está
    indisponível — sem travar o fluxo do usuário.
  - Para a câmera e libera o stream corretamente ao fechar o leitor,
    ao trocar para entrada manual, ou ao detectar um código.
- `js/pages/products.js`: a tela de detalhes do produto (Etapa 5)
  ganhou o botão "📷 Escanear" ao lado do campo de código manual,
  usando o mesmo fluxo de validação/conflito (`tentarAdicionarCodigo`)
  para os dois caminhos (manual ou câmera). `abrirDetalhesProduto` e
  `abrirFormularioNovoProduto` passaram a ser exportadas para reuso
  pela tela Início; `abrirFormularioNovoProduto` aceita agora
  `{ codigoParaAssociar }` opcional para já associar um código ao
  produto assim que ele é criado.
- `js/pages/home.js` implementado (ação rápida, fora do escopo do
  Dashboard completo da Etapa 10): o botão "📷 Escanear produto"
  abre o leitor e usa o código para localizar um produto existente
  (abrindo seus detalhes) ou, se o código não estiver cadastrado,
  oferece cadastrar um produto novo já com esse código associado.
- `css/components.css`: estilos do overlay do leitor (`.scanner-*`,
  reaproveitando as variáveis já usadas no modal) e do layout lado a
  lado dos botões "Escanear" / "Adicionar" no formulário de código.
- `index.html`: removido texto de espaço reservado da tela Produtos
  que já estava desatualizado (a funcionalidade foi implementada na
  Etapa 5).
- `sw.js`: `CACHE_VERSION` incrementada para `v2`, já que o conteúdo
  de vários arquivos do app shell mudou nesta etapa.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos). A leitura por câmera depende
de APIs de navegador (`BarcodeDetector`, `getUserMedia`) e de um
dispositivo com câmera real, que não estavam disponíveis neste
ambiente de desenvolvimento nesta sessão (sem acesso à rede para
instalar um navegador headless, diferente das etapas anteriores em
que isso foi possível). Por isso, a Etapa 6 não teve teste
automatizado de ponta a ponta como as Etapas 3 e 4 — em vez disso,
foi feita revisão manual cuidadosa de cada trecho (IDs do HTML
conferidos com os seletores do JS, imports/exports conferidos,
tratamento de erro e de permissão negada revisado linha a linha).
**Recomenda-se testar manualmente num celular Android com Chrome**
antes de considerar esta etapa totalmente concluída: abrir a tela
Produtos → detalhes de um produto → "📷 Escanear"; e também o botão
"📷 Escanear produto" na tela Início (testando um código já
cadastrado e um código novo).

### Próxima etapa planejada

Etapa 7 — Reposição (marcar produto para repor, listar pendentes e
concluídos).

## Etapa 7 — Reposição

- `js/pages/replenishment.js` implementado: tela Reposição com duas
  abas ("Pendentes" / "Concluídos", componente `.segmented-control`
  novo), listando os itens com o nome do produto (via `obterProduto`)
  e a data de criação/conclusão. Cada item pendente tem um botão
  "✅" para concluir; tocar no nome do item (pendente ou concluído)
  abre os detalhes do produto (reaproveitando `abrirDetalhesProduto`
  da Etapa 6).
- `js/components/product-card.js`: card do produto ganhou o botão
  "📦 Repor" (usa `adicionarReposicao`, que já evita duplicata de
  pendente para o mesmo produto desde a Etapa 3). Quando o produto já
  está pendente de reposição, o botão vira "✅" desabilitado — o card
  passou a receber `{ pendenteReposicao }` como segundo argumento.
- `js/pages/products.js`: `renderizarLista()` agora busca também
  `listarPendentes()` para saber quais produtos já estão marcados, e
  trata a nova ação `data-action="repor"` no card. `refreshProductsPage`
  exportada.
- `js/app.js`: passou a existir um pequeno mecanismo de atualização
  ao trocar de aba (`REFRESH_AO_ENTRAR`) — entrar em Produtos ou
  Reposição sempre busca os dados mais recentes, para que uma
  mudança feita numa tela (ex.: concluir uma reposição) já apareça
  refletida na outra (ex.: o botão "📦" volta a ficar disponível no
  card do produto) sem precisar recarregar a página.
- `css/components.css`: estilos do `.segmented-control` (abas),
  `.reposicao-item` e do estado "ativo/desabilitado" do botão de
  reposição no card do produto.
- `index.html`: tela Reposição deixou de ser placeholder — agora tem
  as abas e o container da lista.
- `sw.js`: `CACHE_VERSION` incrementada para `v3`.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e o CSS teve as chaves
conferidas (balanceadas). Como nas etapas anteriores desta sessão,
não havia navegador disponível neste ambiente para um teste
automatizado de ponta a ponta (sem acesso à rede para instalar
Playwright/jsdom); a verificação foi por revisão manual cuidadosa:
- Conferido que `adicionarReposicao` (Etapa 3) já implementa a regra
  de não duplicar item pendente para o mesmo produto — a tela apenas
  chama essa função já existente e testada.
- Conferido o fluxo de dados do card do produto: `renderizarLista()`
  busca pendentes uma vez e monta um `Set` de `produtoId`, e o botão
  "📦"/"✅" reflete corretamente esse estado a cada renderização.
- Conferido que `nome` do produto é escapado (`escapeHTML`) também na
  lista de Reposição, seguindo o mesmo cuidado já usado nas listas de
  Produtos e de códigos de barras.
- Conferida a navegação entre abas (Pendentes/Concluídos) e entre
  telas (Produtos ↔ Reposição), incluindo o novo mecanismo de
  atualização automática ao entrar em cada tela.

**Recomenda-se um teste manual no navegador** (passo a passo do
`README.md`) para confirmar no ambiente real: marcar um produto para
repor, ver o botão do card mudar para "✅", ir à aba Reposição,
concluir o item, e voltar à tela Produtos para confirmar que o botão
"📦" voltou a ficar disponível.

### Próxima etapa planejada

Etapa 8/9 — Validades (cadastro de validade por produto, cálculo de
status crítico/atenção/normal/vencido e listagem).

## Etapa 8/9 — Validades

- `js/utils/dates.js` implementado: `calcularDiasRestantes` (dias até
  a validade, negativo se já venceu, comparando por dia local, sem
  hora), `classificarValidade` (aplica os limites de
  `VALIDADE_LIMITES` de `js/config/config.js` — crítico até 7 dias,
  atenção até 30, normal acima disso, vencido se negativo),
  `formatarDataValidade` (DD/MM/AAAA) e `textoDiasRestantes` (texto
  amigável, ex.: "Vence em 5 dias", "Vence hoje", "Venceu há 2 dias").
- `js/components/expiration-card.js` implementado: card de validade
  reutilizado em dois contextos — na tela Validades (com nome do
  produto, linha clicável) e nos detalhes do produto (sem nome, já
  que o contexto é um produto só) — sempre com o badge de status
  (reaproveitando as classes `.badge-critico/atencao/normal/vencido`
  já preparadas no CSS desde a Etapa 2) e botão de remover.
- `js/pages/products.js`: os detalhes do produto (mesmo modal aberto
  pelo botão "🔗" no card, que já continha os códigos de barras desde
  a Etapa 5) ganharam uma segunda seção, "Validades" — segue o mesmo
  padrão já usado para códigos: lista das validades do produto +
  formulário para adicionar uma nova (campo de data) + remoção com
  confirmação. Decisão de design: não foi criada uma tela ou modal
  separados só para cadastrar validade, reaproveitando a tela de
  detalhes já existente, com uma seção a mais — consistente com como
  a Etapa 5 tratou os códigos de barras.
- `js/pages/expirations.js` implementado: a tela Validades lista as
  validades de **todos** os produtos (usa `listarTodasValidades`, da
  Etapa 3), ordenadas por urgência (vencido → crítico → atenção →
  normal e, dentro do mesmo grupo, pela data mais próxima primeiro).
  Tocar no nome/data de um item abre os detalhes do produto
  correspondente (reaproveitando `abrirDetalhesProduto`); o botão
  🗑️ remove a validade, com confirmação.
- `js/app.js`: tela Validades passou a ter inicialização própria
  (`initExpirationsPage`) e entrou no mecanismo de atualização ao
  trocar de aba (`REFRESH_AO_ENTRAR`), para refletir uma validade
  recém-cadastrada nos detalhes de um produto assim que o usuário
  abre a aba Validades, sem precisar recarregar a página.
- `index.html`: tela Validades deixou de ser placeholder — agora tem
  o container da lista.
- `css/components.css`: estilos do item de validade
  (`.expiration-item` e subclasses), reaproveitando o mesmo padrão
  visual já usado para `.reposicao-item` na Etapa 7.
- `sw.js`: `CACHE_VERSION` incrementada para `v4`.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e o CSS teve as chaves
conferidas (balanceadas — 79 aberturas e 79 fechamentos). Como nas
etapas anteriores desta sessão, não havia navegador disponível neste
ambiente para um teste automatizado de ponta a ponta; a verificação
foi por revisão manual cuidadosa:
- Conferida a lógica de `calcularDiasRestantes`/`classificarValidade`
  manualmente com datas de exemplo (hoje, amanhã, daqui a 7 dias,
  daqui a 8 dias, daqui a 30 dias, daqui a 31 dias, ontem) contra os
  limites de `VALIDADE_LIMITES`, confirmando os quatro status nos
  limites exatos (7 dias ainda é crítico, 8 já é atenção; 30 dias
  ainda é atenção, 31 já é normal).
- Conferido que a data é interpretada como data **local** (não UTC) —
  `paraDataLocal` monta o `Date` a partir de ano/mês/dia separados,
  evitando o problema comum de `new Date('YYYY-MM-DD')` exibir o dia
  anterior em fusos horários negativos (caso do Brasil).
- Conferido o fluxo de dados nos detalhes do produto: a seção de
  validades é recarregada (`renderizarListaDeValidades`) após
  adicionar ou remover, sem precisar fechar e reabrir o modal — mesmo
  padrão já usado para códigos de barras.
- Conferida a ordenação da tela Validades (por status de urgência e,
  dentro do mesmo status, por data) e que `nome` do produto é
  escapado (`escapeHTML`, via `renderExpirationCardHTML`), seguindo o
  mesmo cuidado das listas anteriores.
- Conferido que um produto sem nenhuma validade cadastrada mostra o
  estado vazio corretamente, tanto na tela Validades quanto nos
  detalhes do produto.

**Recomenda-se um teste manual no navegador** (passo a passo do
`README.md`) para confirmar no ambiente real: nos detalhes de um
produto, cadastrar uma validade vencida, uma para os próximos dias e
uma para depois de 30 dias, conferir que os três badges aparecem
corretos; ir à tela Validades e conferir a ordem (vencido primeiro);
remover uma validade em cada tela e confirmar que some das duas
listas.

### Próxima etapa planejada

Etapa 10 — Dashboard da tela Início (resumo real de reposição
pendente, validades próximas e total de produtos cadastrados, no
lugar dos cards com "—" que existem desde a Etapa 2).

## Etapa 10 — Dashboard da tela Início

- `js/pages/home.js`: implementado `renderResumoHome`, que calcula e
  exibe os três números reais nos cards já existentes desde a Etapa 2
  (`#home-summary-reposicao`, `#home-summary-validades`,
  `#home-summary-produtos`):
  - **Reposição pendente**: `listarPendentes().length` (Etapa 3/7).
  - **Validades próximas**: conta as validades cujo status (via
    `classificarValidade`, Etapa 8/9) é `vencido`, `critico` ou
    `atencao` — ou seja, tudo que não é `normal`. Decisão de design:
    somar os três porque um item vencido também precisa de atenção
    imediata, então não faria sentido excluí-lo do total mostrado no
    resumo rápido da tela Início.
  - **Produtos cadastrados**: `listarProdutos().length` (Etapa 3/4).
  - Os três cards passaram a ser clicáveis: tocar em qualquer um leva
    direto à aba correspondente (Reposição, Validades ou Produtos),
    reaproveitando os mesmos botões de navegação já existentes (sem
    duplicar a lógica de troca de tela do `app.js`).
- `js/app.js`: tela Início entrou no mecanismo `REFRESH_AO_ENTRAR`
  (Etapa 7), então o resumo é recalculado toda vez que o usuário volta
  para a aba Início — por exemplo, depois de concluir uma reposição
  ou cadastrar uma validade em outra aba.
- `index.html`: removido o texto de espaço reservado da tela Início.
- `css/components.css`: `.summary-card` ganhou `cursor: pointer`,
  para indicar visualmente que os cards agora são clicáveis.
- `sw.js`: `CACHE_VERSION` incrementada para `v5`.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e o CSS teve as chaves
conferidas (balanceadas — 79 aberturas e 79 fechamentos). Como nas
etapas anteriores desta sessão, não havia navegador disponível neste
ambiente para um teste automatizado de ponta a ponta; a verificação
foi por revisão manual cuidadosa:
- Conferido que os três `Promise.all` buscam os dados em paralelo e
  que os `id`s usados em `document.getElementById` batem exatamente
  com os já existentes no HTML desde a Etapa 2 (nenhum id novo foi
  necessário).
- Conferido que `ligarCliqueNosCards` localiza corretamente o
  `.summary-card` pai de cada `span` de valor (`.closest`) e que o
  seletor `.nav-item[data-target="..."]` corresponde aos botões reais
  da navegação inferior em `index.html`.
- Conferido que `renderResumoHome` não quebra se algum elemento não
  existir no DOM (retorna cedo), mesma defesa já usada nas outras
  telas.

**Recomenda-se um teste manual no navegador** (passo a passo do
`README.md`) para confirmar no ambiente real: com alguns produtos,
reposições e validades cadastrados, conferir que os três números da
tela Início batem com o que aparece em cada aba, que tocar em cada
card navega para a aba certa, e que os números mudam ao concluir uma
reposição ou remover uma validade e voltar para a Início.

### Próxima etapa planejada

Etapa 11 — Histórico (registro cronológico dos principais eventos do
app: produtos, códigos, reposição e validades).

## Etapa 11 — Histórico

- **Correção de plano**: o usuário enviou a lista oficial das 15
  etapas do projeto. A Etapa 8/9 já feita nesta sessão corresponde,
  no plano oficial, às Etapas 8 (Sistema de validades) e 9 (Tela de
  atenção/validades próximas) — cobertas juntas pela tela Validades
  já implementada (cadastro + lista ordenada por urgência), então
  nenhum trabalho adicional foi necessário por causa disso. A partir
  desta etapa, o changelog passa a seguir a numeração oficial:
  Etapa 11 = Histórico, Etapa 12 = Backup e restauração, Etapa 13 =
  Tratamento de erros e diagnóstico, Etapa 14 = Refinamento de
  interface/mobile, Etapa 15 = Testes gerais e preparação final.
- `js/config/config.js`: nova store `HISTORICO`; `DB_VERSION`
  incrementada para `2`.
- `js/db/database.js`: `upgradeSchema` ganhou o bloco `oldVersion < 2`,
  criando a object store `historico` (id autoIncrement, índices
  `criadoEm` e `tipo`) sem mexer nas stores já existentes — quem já
  tinha o app instalado localmente terá a nova store criada
  automaticamente na próxima abertura, sem perder dados.
- `js/db/history.js` implementado: `registrarEvento({tipo, descricao,
  produtoId})`, `listarHistorico()` e `limparHistorico()`. A
  `descricao` é montada por quem registra o evento (já com o nome do
  produto), porque o produto referenciado pode ser excluído depois —
  o histórico não deve depender de reconsultar dados que podem não
  existir mais.
- Pontos onde um evento passou a ser registrado (sempre logo após o
  `showToast` correspondente, na camada `js/pages/`, para não misturar
  esse efeito colateral com as funções genéricas de `js/db/`):
  - `js/pages/products.js`: produto cadastrado, editado e excluído;
    código de barras adicionado e removido; validade cadastrada e
    removida; produto marcado para repor.
  - `js/pages/replenishment.js`: reposição concluída.
- `js/pages/settings.js` implementado: a tela Configurações ganhou o
  botão "📜 Ver histórico", que abre um modal (reaproveitando
  `js/components/modal.js`, o mesmo já usado nos detalhes do produto)
  com a lista de eventos — mais recente primeiro, cada um com ícone
  por tipo, descrição e data/hora — e um botão "Limpar histórico"
  (com confirmação). Decisão de design: o Histórico não ganhou uma
  aba própria na navegação inferior; ficou acessível a partir de
  Configurações para não apertar os 5 itens já existentes na barra
  inferior em telas pequenas de celular.
- `index.html`: botão "📜 Ver histórico" adicionado à tela
  Configurações.
- `css/components.css`: estilos da lista de histórico
  (`.history-item` e subclasses).
- `sw.js`: `js/db/history.js` adicionado ao `APP_SHELL`;
  `CACHE_VERSION` incrementada para `v6`.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e o CSS teve as chaves
conferidas (balanceadas — 87 aberturas e 87 fechamentos). Como nas
etapas anteriores desta sessão, não havia navegador disponível neste
ambiente para um teste automatizado de ponta a ponta; a verificação
foi por revisão manual cuidadosa:
- Conferido que a migração de schema só cria a store nova quando
  `oldVersion < 2`, sem recriar ou apagar as stores da v1 — segue
  exatamente o mesmo padrão de guarda já usado no bloco `oldVersion <
  1` desde a Etapa 3.
- Conferido, em cada ponto de chamada, que `registrarEvento` só roda
  **depois** da operação principal e do `showToast` terem tido
  sucesso — um evento não é registrado se, por exemplo, a associação
  de um código falhar por conflito.
- Conferida a ausência de import circular: `js/pages/settings.js`
  importa de `js/db/history.js` e `js/components/*`, sem depender de
  `js/pages/products.js` nem o contrário.
- Conferido que `descricao` usa `escapeHTML` na exibição
  (`eventoItemHTML`, em `settings.js`), seguindo o mesmo cuidado já
  usado nas demais listas do app.
- Conferido manualmente o botão "Limpar histórico": só aparece quando
  há eventos, pede confirmação antes de apagar e fecha o modal depois
  (a lista, se reaberta, viria vazia).

**Recomenda-se um teste manual no navegador** (passo a passo do
`README.md`) para confirmar no ambiente real: com o app já instalado
numa versão anterior, abrir e checar que os dados antigos continuam
lá (migração de schema); cadastrar/editar/excluir um produto, marcar
para repor e concluir, cadastrar e remover uma validade; abrir
Configurações → "Ver histórico" e conferir que cada ação aparece
na ordem certa, com a descrição e o horário corretos; testar "Limpar
histórico".

### Próxima etapa planejada

Etapa 12 — Backup e restauração.

## Etapa 12 — Backup e restauração

- `js/db/database.js`: nova função genérica `dbClear(storeName)`,
  reaproveitada tanto por `limparHistorico` (Etapa 11, refatorado para
  usar essa função em vez de repetir a lógica) quanto pela restauração
  de backup.
- `js/db/backup.js` implementado:
  - `gerarBackup()`: lê todas as object stores (`produtos`,
    `codigosBarras`, `reposicao`, `validades`, `historico`) e monta um
    único objeto, com metadados (`app`, `dbVersion`, `criadoEm`) além
    dos dados em si.
  - `pareceBackupValido(obj)`: validação básica de estrutura (existe
    `dados`, é um objeto, e pelo menos uma store conhecida é um
    array) — usada tanto para recusar um arquivo claramente errado
    quanto internamente antes de restaurar.
  - `restaurarBackup(backup)`: para cada store conhecida, limpa tudo
    (`dbClear`) e insere os registros do arquivo com `dbPut` (não
    `dbAdd`), preservando os `id`s originais — importante para não
    quebrar referências como `validade.produtoId`. Stores ausentes no
    arquivo (backup de uma etapa anterior) só são limpas, sem erro.
    Formato do arquivo documentado em `docs/database.md`.
- `js/utils/storage.js` implementado (estava vazio desde a Etapa 1):
  `lerStorage`/`salvarStorage`, um wrapper fino sobre `localStorage`
  (com prefixo de chave e try/catch) — usado só para guardar a data do
  último backup feito neste aparelho, nunca para os dados do app em si
  (que continuam 100% no IndexedDB).
- `js/pages/settings.js`: tela Configurações ganhou a seção "Backup",
  com:
  - **"💾 Fazer backup"**: chama `gerarBackup()`, baixa o resultado
    como arquivo `.json` (via `Blob` + link temporário — técnica
    padrão para download client-side, sem precisar de permissão
    especial do navegador) e atualiza o texto "Último backup: ...".
  - **"♻️ Restaurar backup"**: abre um `<input type="file">` oculto;
    ao escolher um arquivo, lê como texto, faz `JSON.parse`, valida
    com `pareceBackupValido`, pede confirmação explícita (deixando
    claro que a ação **substitui** todos os dados atuais e não pode
    ser desfeita) e só então chama `restaurarBackup`. Depois de
    restaurar com sucesso, registra um evento `backup_restaurado` no
    histórico (já o histórico restaurado, por isso o registro acontece
    **depois** da restauração) e recarrega a página — decisão de
    design: mais simples e mais seguro do que tentar atualizar cada
    tela manualmente, garantindo que nada fique com dados antigos em
    memória.
  - Erros (arquivo não é JSON válido, arquivo não parece um backup
    deste app, falha ao ler/escrever no IndexedDB) mostram um toast de
    erro em vez de travar a tela.
- `index.html`: seção "Backup" adicionada em Configurações, com os
  dois botões, o texto de último backup e o input de arquivo oculto.
- `css/components.css`: `.settings-group`, `.settings-group-title` e
  `.settings-info` para o novo agrupamento visual.
- `sw.js`: `js/db/backup.js` adicionado ao `APP_SHELL`;
  `CACHE_VERSION` incrementada para `v7`.

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e o CSS teve as chaves
conferidas (balanceadas — 90 aberturas e 90 fechamentos). Como nas
etapas anteriores desta sessão, não havia navegador disponível neste
ambiente para um teste automatizado de ponta a ponta; a verificação
foi por revisão manual cuidadosa:
- Conferido que `restaurarBackup` usa `dbPut` (que respeita a chave
  explícita do registro) e não `dbAdd` — testar isso errado geraria
  produtos com um novo `id` autoIncrement, quebrando toda referência
  de `produtoId` nas outras stores restauradas.
- Conferido que, segundo a especificação do IndexedDB, inserir
  registros com chave explícita numa store com key generator
  (`autoIncrement`) atualiza o gerador para ficar acima da maior chave
  inserida — ou seja, depois de restaurar, um novo evento de
  histórico (`registrarEvento`) não corre risco de colidir com um `id`
  já restaurado.
- Conferido que `pareceBackupValido` rejeita `null`/`undefined`,
  tipos primitivos e objetos sem `dados`, evitando um erro não tratado
  se o usuário escolher um arquivo `.json` qualquer por engano.
- Conferido que o `<input type="file">` tem o valor limpo
  (`input.value = ''`) logo após a leitura, para permitir escolher o
  mesmo arquivo de novo (o navegador não dispara `change` de novo se o
  `value` não mudar).
- Conferido, por leitura, que `fazerBackup` e `restaurarDeArquivo` têm
  todos os pontos de falha (`gerarBackup`, `JSON.parse`,
  `restaurarBackup`) dentro de blocos `try/catch` com toast de erro,
  em vez de deixar uma `Promise` rejeitada sem tratamento.

**Recomenda-se um teste manual no navegador** (passo a passo do
`README.md`) para confirmar no ambiente real: com alguns produtos,
códigos, reposições, validades e eventos de histórico cadastrados,
tocar "Fazer backup" e conferir que o arquivo baixa e abre como JSON
válido; cadastrar mais alguma coisa (para o estado atual ficar
diferente do backup); tocar "Restaurar backup", escolher o arquivo
salvo, confirmar, e verificar que o app volta exatamente ao estado do
momento do backup (inclusive o histórico, com o novo evento
"Backup restaurado" no topo); testar também restaurar um arquivo
`.txt` qualquer ou um `.json` sem o formato esperado, para confirmar
que aparece um erro amigável em vez de travar.

### Próxima etapa planejada

Etapa 13 — Tratamento de erros e área de diagnóstico.

## Ajuste pós-Etapa 12 (1/4) — Ação rápida ao escanear produto já cadastrado

- `js/db/replenishment.js`: nova função `obterPendentePorProduto(produtoId)`,
  que retorna o item de reposição pendente de um produto (ou `null`),
  para saber se ele já está marcado para repor sem precisar filtrar a
  lista completa toda vez.
- `js/pages/home.js`: ao escanear um código já associado a um produto,
  em vez de ir direto para a tela de detalhes (códigos/validades),
  agora abre um modal de ação rápida com o nome/marca do produto e dois
  botões: "📦 Adicionar para reposição" (marca direto, sem sair do
  fluxo de escaneamento) e "🔗 Ver detalhes / códigos" (abre a tela de
  detalhes de sempre). Se o produto já estiver pendente de reposição,
  o botão aparece desabilitado com "✅ Já está na lista de reposição".
- `css/components.css`: estilos `.scan-result`, `.scan-result-nome`,
  `.scan-result-detalhes` para o novo modal.

### Verificação

Sem navegador disponível neste ambiente; `node --check` rodado em
todos os arquivos `.js` do projeto (sintaticamente válidos). Revisão
manual do fluxo: `obterPendentePorProduto` usa o mesmo índice
`produtoId` já criado no schema (v1), não exige migração; o botão de
reposição só liga o evento de clique quando `jaPendente` é falso
(evita marcar duas vezes por engano); o fluxo de código não cadastrado
(abre formulário de novo produto) não foi alterado.

**Teste manual recomendado**: escanear (ou digitar manualmente) um
código já associado a um produto e conferir que aparece o modal com
os dois botões; tocar "Adicionar para reposição" e conferir que o
produto aparece na aba Reposição → Pendentes; escanear o mesmo código
de novo e conferir que o botão já aparece desabilitado como
"✅ Já está na lista de reposição".

## Ajuste pós-Etapa 12 (2/4) — Aviso de produto duplicado ao cadastrar

- `js/db/products.js`: nova função `buscarProdutoDuplicado(nome, marca)`,
  que procura um produto já cadastrado com o mesmo nome e a mesma
  marca (comparação sem diferenciar maiúsculas/minúsculas, ignorando
  espaços nas pontas). Só considera duplicado quando nome **e** marca
  batem — dois produtos com o mesmo nome e marcas diferentes (ou uma
  delas vazia) não são tratados como duplicados.
- `js/pages/products.js`: o formulário de "Novo produto" (usado tanto
  pelo botão "+ Novo produto" quanto pelo fluxo de código escaneado
  sem cadastro) agora checa duplicidade antes de salvar. Se encontrar
  um produto com o mesmo nome+marca, mostra um aviso no próprio
  formulário com duas opções:
  - **"Usar este produto"**: não cria um novo produto; se o cadastro
    veio de um código escaneado, associa o código ao produto já
    existente.
  - **"Cadastrar mesmo assim (é diferente)"**: ignora o aviso e
    cadastra normalmente (ex.: dois produtos que só parecem iguais
    pelo nome/marca, mas o usuário sabe que são diferentes).
  A checagem de duplicidade só acontece ao **criar** produto — editar
  um produto existente não foi alterado.
- `css/components.css`: novo estilo `.form-warning` (fundo amarelo
  claro, borda na cor de "atenção") para o aviso de duplicidade.

### Verificação

Sem navegador disponível neste ambiente; `node --check` rodado em
todos os arquivos `.js` do projeto. Revisão manual do fluxo:
`buscarProdutoDuplicado` retorna `null` se o nome vier vazio (evita
falso positivo antes da validação normal de "nome obrigatório");
o botão de submit do formulário fica desabilitado enquanto o aviso
está visível, para não deixar clicar em "Salvar" de novo por engano
enquanto decide; ao clicar em "Cadastrar mesmo assim", o aviso é
removido e o botão reabilitado antes de criar o produto, para caso o
usuário precise repetir o fluxo depois (edição futura, por exemplo).

**Teste manual recomendado**: cadastrar um produto (ex. "Água e Sal",
marca "Marilan"); tentar cadastrar de novo com o mesmo nome e marca
(inclusive testando com espaços extras ou letras maiúsculas) e
conferir que aparece o aviso; testar "Usar este produto" (não deve
criar um segundo produto na lista) e, num segundo teste, "Cadastrar
mesmo assim" (deve criar normalmente); testar também que um nome
igual com marca diferente (ou marca vazia) **não** dispara o aviso.

## Ajuste pós-Etapa 12 (3/4) — Busca e filtro por marca em Produtos

- `index.html`: novo bloco `.produtos-filtros` na tela Produtos, com um
  campo de busca (`#produtos-busca`, `type="search"`) e um seletor de
  marca (`#produtos-filtro-marca`), entre o botão "+ Novo produto" e a
  lista.
- `js/pages/products.js`:
  - Estado de filtro (`filtroBusca`, `filtroMarca`) mantido em memória
    (não persiste entre sessões/recarregamentos da página).
  - `produtoCorrespondeAosFiltros`: nome contém o texto buscado
    (sem diferenciar maiúsculas/minúsculas, ignorando espaços) **e**
    marca bate com a selecionada (quando houver filtro de marca).
  - `marcasDistintas` / `atualizarOpcoesDeMarca`: reconstrói as opções
    do seletor de marca a partir dos produtos cadastrados no momento
    (sem lista fixa/hardcoded), deduplicando marcas digitadas com
    letras diferentes (ex. "Adria" e "adria" contam como uma só opção,
    usando a primeira grafia encontrada como rótulo) e preservando a
    marca selecionada entre atualizações da lista quando ela ainda
    existir.
  - `renderizarLista` agora filtra os produtos antes de desenhar os
    cards; mensagens de lista vazia diferenciam "nenhum produto
    cadastrado ainda" de "nenhum produto encontrado com esse filtro".
  - Categoria não ganhou filtro próprio nesta etapa — o pedido original
    citava "marca/tipo"; como cada produto só tem uma marca (mais
    específico e já usado para diferenciar duplicados na etapa
    anterior), o filtro ficou por marca. Se depois for útil filtrar
    também por categoria, dá pra somar um segundo seletor.
- `css/components.css`: `.produtos-filtros` (busca e seletor lado a
  lado, busca ocupando mais espaço).

### Verificação

Sem navegador disponível neste ambiente; `node --check` rodado em
todos os arquivos `.js`. Revisão manual: os filtros são reaplicados
toda vez que `renderizarLista` roda (inclusive após criar/editar/
excluir produto ou marcar reposição), então o resultado filtrado nunca
fica desatualizado; `atualizarOpcoesDeMarca` roda antes da checagem de
lista vazia, então o seletor de marcas fica correto mesmo quando o
filtro atual não encontra nenhum produto.

**Teste manual recomendado**: com vários produtos cadastrados,
digitar parte de um nome na busca e conferir que a lista filtra em
tempo real; selecionar uma marca no seletor e conferir que só aparecem
produtos daquela marca; combinar busca + marca ao mesmo tempo; excluir
o único produto de uma marca e conferir que ela some do seletor.

## Ajuste pós-Etapa 12 (4/4) — Marcar item de reposição como "falta"

- `js/db/replenishment.js`: novo status `'falta'` para a entidade
  Reposição (além de `'pendente'` e `'concluido'`), com o campo
  `faltaEm` guardando quando foi marcado. Novas funções:
  - `marcarFalta(id)`: tira um item pendente da lista de pendentes sem
    contar como reposição feita — para quando não havia mais o
    produto no estoque para repor.
  - `listarFalta()`: lista os itens marcados como falta.
  - `reativarReposicao(id)`: volta um item de "falta" para "pendente",
    reaproveitando o mesmo registro (não cria duplicata) — para quando
    o estoque chegou de novo.
  Não precisou de migração de schema: `status` já é uma string
  qualquer no índice existente, só ganhou mais um valor possível.
- `index.html`: terceira aba "Falta" no segmented control da tela
  Reposição (além de "Pendentes" e "Concluídos").
- `js/pages/replenishment.js`: reescrito para funcionar com 3 abas de
  forma genérica (cada aba define sua função de listagem, campo de
  data e mensagem de lista vazia) em vez de um booleano fixo
  `pendente`/`concluído`. Ações por aba:
  - **Pendentes**: botão 🚫 "Marcar falta no estoque" (novo) ao lado
    do ✅ "Concluir" que já existia.
  - **Falta**: botão 🔁 "Marcar para repor de novo" (reativa o mesmo
    item, sem duplicar).
  - **Concluídos**: sem ações, como antes.
- `js/pages/settings.js`: novo tipo de evento `reposicao_falta` no
  mapa de ícones do Histórico (🚫), para os eventos "marcado como
  falta" aparecerem certos na tela de Histórico.
- `css/components.css`: `.reposicao-item-actions` (os itens da lista
  de Reposição agora podem ter mais de um botão de ação lado a lado).

### Verificação

Sem navegador disponível neste ambiente; `node --check` rodado em
todos os arquivos `.js` do projeto. Revisão manual do fluxo:
`reativarReposicao` atualiza `criadoEm` para a data da reativação (faz
sentido reaparecer como "adicionado agora" na aba Pendentes, já que
antes de reativar ele nem aparecia lá) e limpa `concluidoEm`/`faltaEm`;
conferido que marcar falta ou reativar não mexe em nenhum outro
registro (não cria produto novo, não mexe em código de barras); a
tela de Histórico já tinha um mapa de ícones por `tipo` — sem
adicionar `reposicao_falta` nele, o evento apareceria com o ícone
genérico "•", por isso a atualização em `settings.js`.

**Teste manual recomendado**: marcar um produto para repor; na aba
Pendentes, tocar 🚫 e conferir que ele sai de Pendentes e aparece na
aba Falta com a data certa; conferir no Histórico que aparece o
evento com o ícone 🚫; na aba Falta, tocar 🔁 e conferir que o item
volta a aparecer em Pendentes (e não duplicado); conferir que o card
do produto na tela Produtos volta a mostrar o botão 📦 disponível
enquanto o item está em "Falta" (não pendente).

### Próxima etapa planejada

Etapa 13 — Tratamento de erros e área de diagnóstico (conforme
planejado originalmente), incorporando também o aprendizado dos 4
ajustes acima.

## Etapa 14 — Refinamento da interface e experiência mobile

- **Nota de ordem**: a pedido do usuário, a Etapa 14 foi feita antes da
  Etapa 13 (que continua planejada, e é o próximo passo depois desta).
  Nenhuma funcionalidade nova foi adicionada nesta etapa — é só
  refinamento visual/interação sobre o que já existia.
- `css/layout.css`:
  - `#app-header` passou a somar `env(safe-area-inset-top)` à altura
    (notch/ilha dinâmica em iPhones), mantendo a área de conteúdo com
    os mesmos 56px de sempre (a área extra é só padding-top; a altura
    total cresce, não o espaço do título).
  - `.page` ganhou uma animação de entrada (fade + leve deslocamento
    vertical) toda vez que uma seção deixa de ter `.is-hidden` — não
    precisou de nenhuma mudança em `app.js`, já que a troca de
    `display: none` para `flex` já conta como "entrada" para a
    animação CSS.
  - `.nav-item` ganhou `transition: transform` (usado pelo feedback
    tátil abaixo, em `components.css`).
- `css/components.css`:
  - Feedback tátil: `.btn`, `.btn-icon`, `.nav-item`, `.segmented-btn`,
    `.summary-card` e `.product-card` encolhem levemente
    (`scale(0.97)`) ao serem tocados/clicados (`:active`), com
    transição rápida (0.1s) — dá sensação de resposta imediata ao
    toque antes mesmo da ação terminar.
  - `.btn:disabled` ganhou estilo (opacidade reduzida), usado pelo
    novo estado de carregamento do backup/restauração.
  - Estados de foco visível (`:focus-visible`) em botões e abas, para
    quem usa teclado físico (tablet/desktop) — sem mudar a aparência
    para quem usa só toque.
  - `.produtos-filtros` (busca + filtro de marca) ficou fixa (`sticky`)
    logo abaixo do header ao rolar a lista de Produtos — em listas
    longas, filtrar não deveria exigir rolar de volta ao topo. O
    `top` usado soma a altura do header com a área segura, então a
    barra nunca fica escondida atrás do header em nenhum aparelho.
  - `.modal-box` e `.scanner-box` ganharam rolagem com inércia no iOS
    (`-webkit-overflow-scrolling: touch`) e `overscroll-behavior:
    contain`, para o gesto de rolar dentro do modal/leitor não
    "vazar" e rolar o fundo da página junto.
- `css/main.css`:
  - `button`, `a` e `select` ganharam `touch-action: manipulation`,
    evitando o atraso/zoom de duplo toque em elementos interativos no
    celular (inputs de texto não foram incluídos, para não alterar o
    comportamento padrão de seleção/toque neles).
  - `@media (prefers-reduced-motion: reduce)` desliga globalmente as
    novas animações/transições (praticamente zera a duração) para
    quem tem essa preferência ativada no sistema — sem remover
    nenhuma funcionalidade, só o efeito visual.
- `js/components/modal.js`:
  - Tecla **Esc** fecha o modal (igual ao botão "✕"), com o listener
    de teclado adicionado ao abrir e removido ao fechar.
  - Foco automático: quando o formulário do modal já tem um campo
    marcado com `autofocus` no HTML (formulários de novo/editar
    produto), o foco vai pra lá ao abrir — o atributo sozinho não
    funciona porque o conteúdo é inserido via `innerHTML`. **Decisão
    de design**: modais sem `autofocus` explícito (ex.: detalhes do
    produto, histórico) **não** recebem foco automático em nenhum
    campo de texto — nesses casos o foco vai para o botão de fechar.
    A ideia é não disparar o teclado virtual sozinho ao abrir um
    modal que muitas vezes é só para consulta (ex.: abrir os
    detalhes de um produto só para ver os códigos já cadastrados).
- `js/components/barcode-scanner.js`: tecla **Esc** também fecha o
  leitor de código de barras (chama `closeScanner()`, que já para a
  câmera corretamente), com o mesmo padrão de listener adicionado/
  removido do modal.
- `js/components/toast.js`: o container de toasts ganhou
  `role="status"` e `aria-live="polite"`, para leitores de tela
  anunciarem a mensagem assim que ela aparece, sem precisar que o
  foco esteja nela.
- `js/pages/settings.js`: os botões "💾 Fazer backup" e "♻️ Restaurar
  backup" ficam desabilitados e trocam de texto ("Gerando
  backup...".../"Restaurando...") durante a operação — evita cliques
  duplicados (ex.: gerar dois downloads sem querer) e dá feedback de
  que algo está acontecendo, já que ler/regravar todas as stores do
  IndexedDB pode ser perceptível com muitos dados cadastrados.
- `sw.js`: `CACHE_VERSION` incrementada para `v8`, já que vários
  arquivos do app shell mudaram nesta etapa.
- Itens considerados e **deixados de fora** desta etapa, com o motivo:
  - *Estado de "carregando" nas listas* (Produtos/Reposição/
    Validades): ao revisar `app.js`, todas as telas já são
    inicializadas (e seus dados já são buscados) assim que o app
    carrega, mesmo as que começam ocultas — e o conteúdo antigo de
    uma lista só é substituído depois que os novos dados chegam, sem
    limpar a tela antes. Ou seja, o "flash" de lista vazia que esse
    tipo de indicador resolveria praticamente não acontece nesta
    arquitetura; adicionar um spinner sem esse problema real seria
    complexidade sem benefício.
  - *Modal de confirmação customizado no lugar de `window.confirm`*:
    o app já usa `window.confirm` de forma consistente desde a Etapa
    4 para todas as confirmações destrutivas (excluir produto,
    remover código/validade, limpar histórico, restaurar backup).
    Trocar por um modal próprio seria uma mudança de comportamento
    maior (não é só visual) e ficou fora do escopo de "refinamento"
    desta etapa — pode ser revisitado depois se o `confirm()` nativo
    incomodar no uso real (ex.: por não poder ser estilizado).

### Verificação

Todo o JavaScript novo/alterado foi validado com `node --check`
(sintaxe correta em todos os arquivos) e todos os 4 arquivos de
`css/` tiveram as chaves conferidas (balanceadas: `components.css`
104/104, `layout.css` 14/14, `main.css` 12/12, `responsive.css`
6/6). Como nas etapas anteriores desta sessão, não havia navegador
disponível neste ambiente (sem acesso à rede) para um teste
automatizado de ponta a ponta; a verificação foi por revisão manual
cuidadosa:

- Conferido que `padding-top: env(safe-area-inset-top, 0)` no header
  soma à `height` (que também inclui o mesmo `env()`) em vez de
  espremer o conteúdo — o mesmo padrão unitless `0` como fallback já
  era usado desde a Etapa 2 em `#app-nav` (`env(safe-area-inset-
  bottom, 0)`), então é um padrão já validado neste projeto.
- Conferido que `.produtos-filtros` usa exatamente o mesmo cálculo de
  altura do header (`calc(var(--header-height) + env(safe-area-
  inset-top, 0))`) para o `top` do sticky, então a barra fica sempre
  colada logo abaixo do header, sem sobrepor nem deixar espaço, em
  qualquer aparelho.
- Conferido, lendo `abrirDetalhesProduto` (Etapa 5/8) e o modal de
  ações rápidas do escaneamento (Etapa 6/ajuste 1), que nenhum dos
  dois tem campo com `autofocus` — confirma que o foco automático do
  modal não vai disparar o teclado virtual ao simplesmente abrir os
  detalhes de um produto ou o resultado de um escaneamento.
  `formularioProdutoHTML` (novo/editar produto) é o único caso com
  `autofocus` no HTML, então é o único que recebe foco automático de
  fato.
- Conferido que o listener de tecla Esc é removido em todo caminho de
  fechamento do modal e do scanner (botão "✕", clique fora, Esc, e
  qualquer chamada a `closeModal()`/`closeScanner()` feita pelas
  páginas depois de uma ação bem-sucedida) — todos passam pela mesma
  função central, então não há como um listener "vazar" e continuar
  ativo depois de fechado.
- Conferido o fluxo de `restaurarDeArquivo`: o botão só é desabilitado
  depois da confirmação (não trava a tela enquanto o usuário ainda
  está decidindo) e é reabilitado no `catch`; no caminho de sucesso
  ele permanece desabilitado de propósito até a página recarregar
  sozinha logo em seguida.
- Conferido que `@media (prefers-reduced-motion: reduce)` usa `*` com
  `!important`, então cobre tanto as transições novas (botões, cards,
  nav) quanto a animação de entrada de página, sem precisar listar
  cada seletor manualmente.

**Recomenda-se um teste manual no navegador** (idealmente num celular
com notch/ilha dinâmica, ex. iPhone recente) para confirmar no
ambiente real: conferir que o header não fica atrás do notch; trocar
de aba e observar a transição suave; tocar em botões/cards e sentir o
feedback de encolher; na tela Produtos, rolar uma lista longa e
conferir que a barra de busca/filtro fica fixa logo abaixo do header;
abrir um modal e apertar Esc para fechar; abrir "Novo produto" e
conferir que o teclado já aparece com o campo Nome focado, e abrir os
detalhes de um produto existente e conferir que o teclado **não**
aparece sozinho; tocar "Fazer backup" e "Restaurar backup" e observar
o botão desabilitado com o texto trocado durante a operação; e, nas
Configurações do sistema/acessibilidade, ativar "reduzir movimento" e
confirmar que as transições somem sem quebrar nada.

### Próxima etapa planejada

Etapa 13 — Tratamento de erros e área de diagnóstico (retomando a
ordem original, conforme combinado com o usuário).

## Etapa 13 — Tratamento de erros e área de diagnóstico

- `js/utils/errorlog.js` implementado: registro de erros para a área
  de Diagnóstico, guardado no `localStorage` (via `js/utils/storage.js`),
  de propósito **separado** do IndexedDB — se o problema for
  justamente o IndexedDB falhando (banco bloqueado, sem quota,
  restrição de navegação privada), o registro de erro não pode
  depender dele também para funcionar. Mantém só os 50 erros mais
  recentes (`registrarErro`, `listarErros`, `limparErros`), e nunca
  lança exceção (um problema ao registrar o erro não pode virar um
  segundo erro por cima do primeiro).
- `js/db/database.js`: todas as operações genéricas (`dbAdd`, `dbPut`,
  `dbGet`, `dbGetAll`, `dbGetAllByIndex`, `dbDelete`, `dbClear`) e a
  abertura do banco agora registram automaticamente qualquer erro no
  log de diagnóstico — sem mudar o comportamento para quem chama: o
  erro original continua sendo relançado normalmente, para os `catch`
  já existentes em `js/db/*` e `js/pages/*` continuarem funcionando
  exatamente como antes. Isso garante que todo erro de IndexedDB, de
  qualquer módulo, fique registrado num único lugar.
- `js/app.js`: tratamento global de erros —
  - `window.addEventListener('error', ...)` e `('unhandledrejection',
    ...)` capturam qualquer erro que escape dos tratamentos
    específicos de cada tela (comum neste app, já que vários handlers
    de clique em `js/pages/` chamam funções assíncronas sem `try/catch`
    próprio — antes desta etapa, um erro ali ficava só no console, sem
    nenhum feedback para quem está usando). Registra no log e avisa
    por um toast discreto (com limite de frequência entre avisos, para
    não alagar a tela se vários erros dispararem em sequência).
  - `initPages()` agora inicia cada tela dentro do seu próprio
    `try/catch` — um bug na inicialização de uma tela não impede as
    outras de funcionarem.
  - Registro de Service Worker também loga falhas no mesmo log.
- `js/pages/settings.js` + `index.html`: nova seção "🔧 Diagnóstico"
  em Configurações (substituindo o texto de espaço reservado), com:
  - **Ambiente**: versão do banco, suporte a IndexedDB/Service
    Worker/leitor de código por câmera/área de transferência, se o
    Service Worker está ativo nesta aba, conexão online/offline,
    instalado como app ou não, e uso de armazenamento
    (`navigator.storage.estimate()`, quando disponível).
  - **Erros registrados**: lista dos erros capturados (automática ou
    manualmente), mais recente primeiro.
  - **"📋 Copiar diagnóstico"**: gera um texto único com tudo isso e
    copia para a área de transferência (`navigator.clipboard`, com
    fallback via `textarea` + `execCommand('copy')` para quando a API
    moderna não está disponível) — pensado para o usuário colar num
    relato de problema sem precisar descrever cada detalhe técnico à
    mão.
  - **"Limpar erros registrados"**: só aparece quando há erros; pede
    confirmação antes de limpar.
- `css/components.css`: `.diag-section` (reaproveita `.settings-group`,
  `.settings-info` e `.history-list` já existentes, com pequenos
  ajustes de alinhamento/espaçamento para a lista de informações).
- `sw.js`: `js/utils/errorlog.js` adicionado ao `APP_SHELL`;
  `CACHE_VERSION` incrementada para `v9`.

### Verificação

Desta vez havia acesso à rede no ambiente de desenvolvimento, então foi
possível montar um ambiente de teste real (Node + jsdom + IndexedDB
simulado via `fake-indexeddb`), em vez de depender só de revisão
manual como nas etapas anteriores desta sessão. Todo o JavaScript foi
validado com `node --check` e as chaves do CSS conferidas (balanceadas).
Rodei 28 verificações automatizadas cobrindo:
- `errorlog.js`: registro, ordenação (mais recente primeiro), limite
  de 50 erros (com descarte dos mais antigos), limpeza, e que nunca
  lança exceção mesmo com dados incompletos.
- `database.js`: que as operações continuam funcionando normalmente
  após o "wrapping" de log (criar, ler, atualizar, apagar produto) e
  que um erro real de IndexedDB (`ConstraintError` ao tentar `add` com
  uma chave já existente) é automaticamente registrado no log **e**
  ainda assim relançado para quem chamou, preservando o comportamento
  anterior.
- `app.js`: que `init()` não lança exceção mesmo com uma tela
  falhando ao iniciar (forçando uma falha real dentro da
  inicialização da tela Produtos) — as demais telas continuam
  funcionando e a falha fica registrada no log; e que os listeners
  globais de `error` e `unhandledrejection` realmente capturam e
  registram os erros.

Todas as 28 verificações passaram.

**Recomenda-se um teste manual no navegador** para confirmar no
ambiente real: em Configurações, abrir "🔧 Ver diagnóstico" e conferir
que as informações de ambiente fazem sentido para o aparelho/navegador
usado; tocar "Copiar diagnóstico" e colar em algum lugar para conferir
o texto gerado; provocar um erro de propósito (ex.: desconectar a
internet no meio de uma operação, se aplicável) e conferir que ele
aparece na lista; testar "Limpar erros registrados".

### Próxima etapa planejada

Etapa 14 já havia sido feita antes desta (a pedido do usuário). Falta
apenas a Etapa 15 — testes gerais, correções, limpeza e preparação
para uso real.

## Etapa 15 — Testes gerais, correções, limpeza e preparação para uso real

- **Revisão completa do projeto**: releitura de todo o código-fonte
  (todas as camadas — `db`, `pages`, `components`, `utils`, `config` —
  e todo o CSS/HTML), em busca de inconsistências, código morto e
  problemas de integração entre etapas feitas em sessões diferentes.
- **Bug corrigido**: remover uma validade pela tela **Validades**
  (lista geral de todos os produtos) não registrava evento no
  Histórico — só removendo pelos detalhes do produto (tela Produtos)
  isso acontecia, já que os dois caminhos chamam `removerValidade`
  mas só um deles chamava `registrarEvento` depois. Agora os dois
  caminhos registram o mesmo tipo de evento (`validade_removida`),
  com a mesma descrição (`Uma validade de "<produto>" foi removida.`),
  incluindo o caso raro em que o produto já foi excluído (mostra
  `Produto #<id> (removido)` em vez de travar por falta do nome).
- **Verificações de integridade entre arquivos** (para pegar erros de
  digitação/referência que só apareceriam em uso real):
  - Todo `id` usado por `document.getElementById(...)` em qualquer
    arquivo `.js` existe de fato no `index.html` — nenhum órfão.
  - Toda classe CSS referenciada pelo JS/HTML tem uma regra
    correspondente em algum arquivo de `css/` (as únicas exceções são
    `.modal-body`, que é um contêiner neutro só para consulta via
    `querySelector`, sem estilo próprio — comportamento já esperado
    desde a Etapa 4).
  - A lista `APP_SHELL` do `sw.js` bate exatamente, arquivo por
    arquivo, com todo o conteúdo real de `js/` — nada cacheado a mais
    nem a menos.
- `js/utils/validation.js`: continuava vazio (esqueleto desde a Etapa
  1). Decisão de manter assim, agora documentada no próprio arquivo:
  as poucas validações que realmente surgiram no projeto são
  específicas de cada entidade e já ficam junto da regra de negócio
  correspondente em `js/db/*` — extrair para um módulo genérico exigiria
  "adivinhar" uma categorização sem nenhum caso real de reuso entre
  elas. Mantido como esqueleto para uma validação futura que seja
  claramente compartilhada por mais de um módulo.
- `sw.js`: `CACHE_VERSION` incrementada para `v10`.
- `README.md`: "Status do projeto" atualizado para refletir a
  conclusão das 15 etapas; seção de limitações conhecidas revisada.

### Verificação

Com o ambiente de teste (Node + jsdom + `fake-indexeddb`) já montado
na Etapa 13, foi possível ir além da revisão manual desta vez: montei
um teste de integração de ponta a ponta que carrega o `index.html`
real (não uma versão reduzida escrita à mão) e simula cliques e
envios de formulário como um usuário real faria, cobrindo o app
inteiro:

- Navegação entre as 5 telas.
- Cadastro de produto, aviso de duplicidade (nome+marca iguais) e
  "usar produto existente" sem criar duplicata.
- Associação de código de barras, incluindo o caso de **conflito**
  (código já usado por outro produto) — confirma que o erro aparece
  no formulário e que o código não é associado ao segundo produto.
- Cadastro de validade vencida e conferência do badge "Vencido".
- Tela Validades: listagem, e a correção do bug acima (remover por
  ali agora registra o evento no Histórico).
- Fluxo completo de Reposição: marcar → aparece em Pendentes → marcar
  falta → aparece em Falta → reativar → volta para Pendentes sem
  duplicar → concluir → aparece em Concluídos → botão "📦 Repor" do
  card volta a ficar disponível.
- Dashboard da tela Início reflete os números corretos após todas as
  operações acima.
- Histórico mostra os eventos registrados; Diagnóstico mostra as
  informações de ambiente, a lista de erros (vazia e depois com um
  erro de teste), e os botões de copiar/limpar aparecem/somem
  corretamente.
- Backup: `gerarBackup()` produz um objeto válido com os dados atuais.
- Editar produto (reflete o novo nome na lista) e excluir produto.
- Busca por texto e filtro por marca na tela Produtos.
- Restauração de backup: apagar todos os produtos manualmente e
  restaurar o backup gerado antes traz de volta a mesma quantidade de
  produtos, **preservando os ids originais** (importante para não
  quebrar referências de outras entidades).

Ao todo, entre os dois scripts de teste desta etapa, **48 de 48
verificações passaram** (além das 28 já registradas na Etapa 13),
incluindo a verificação específica de que o bug do Histórico foi
corrigido.

**Recomenda-se um teste manual final no navegador**, idealmente num
celular Android (o uso real pretendido), cobrindo pelo menos uma vez
cada funcionalidade do app: cadastrar produtos com código de barras
(via câmera e manual) e validade; marcar para repor, concluir e
marcar falta; conferir o Dashboard; ver e limpar o Histórico; fazer um
backup, cadastrar mais alguma coisa e restaurar o backup para
confirmar que volta ao estado salvo; abrir o Diagnóstico e testar
"Copiar diagnóstico"; instalar o app na tela inicial e usar por um
tempo no modo standalone, inclusive offline (modo avião), para
confirmar que o Service Worker está servindo o app shell corretamente.

### Próxima etapa planejada

Nenhuma — as 15 etapas planejadas foram concluídas. O app está pronto
para uso real; ajustes futuros devem partir de necessidades reais
observadas no dia a dia de trabalho, não de um plano pré-definido.

