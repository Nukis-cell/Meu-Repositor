# Arquitetura — Meu Repositor

## Visão geral

Aplicação web pessoal, client-side only (sem backend), instalável como PWA,
com foco em uso rápido durante o trabalho (poucos toques, funcionamento
offline, interface simples).

## Decisões confirmadas na Etapa 1

- **Sem backend / sem servidor**: toda a persistência é local, via
  IndexedDB. Nenhuma funcionalidade essencial depende de internet.
- **Sem frameworks pesados**: HTML/CSS/JS puro, com JavaScript organizado
  em módulos ES (`type="module"`), para manter simplicidade e facilitar
  manutenção por alguém iniciante em programação.
- **Separação em camadas**:
  - `js/db/` — única camada com acesso direto ao IndexedDB. Nenhum outro
    módulo deve chamar a API do IndexedDB diretamente; tudo passa por aqui.
  - `js/pages/` — lógica de cada tela (Início, Reposição, Validades,
    Produtos, Configurações).
  - `js/components/` — peças de UI reutilizáveis entre telas (scanner de
    código de barras, cards, modal, toast).
  - `js/utils/` — funções puras auxiliares (datas, formatação, validação),
    sem estado e sem efeitos colaterais diretos no DOM ou no banco.
  - `js/config/` — constantes e parâmetros globais (nome/versão do banco,
    limites de classificação de validade, etc.), para facilitar ajustes
    futuros sem caçar valores espalhados pelo código.
- **CSS dividido por responsabilidade**: reset/variáveis (`main.css`),
  estrutura de layout (`layout.css`), componentes (`components.css`) e
  responsividade (`responsive.css`), evitando um único arquivo gigante.

## Modelo de dados (resumo conceitual)

Detalhado em `database.md`. Pontos centrais que guiam a arquitetura:

- O **código de barras não é o ID do produto**. Existe uma entidade
  própria de Código de Barras, que aponta para um `produtoId`. Um produto
  pode ter vários códigos; um código não pode apontar para dois produtos.
- **Reposição** é independente de **Validade** — são entidades separadas,
  ambas referenciando um `produtoId`.
- Nenhuma das entidades (Reposição, Validade) exige controle de
  quantidade — o registro representa "existe isso pendente/válido", não
  "quantos existem".
- Validades não se substituem: um produto pode ter várias validades
  simultâneas, cada uma como registro independente.

## Versionamento do banco

O IndexedDB será inicializado com uma versão numérica desde o início
(`DB_VERSION` em `js/config/config.js`), para permitir migrações seguras
de schema caso a estrutura precise mudar em etapas futuras. A lógica de
migração ficará centralizada em `js/db/database.js`.

## O que NÃO está implementado na Etapa 1

Esta etapa cria apenas a estrutura e os arquivos-base (esqueletos com
comentários indicando responsabilidade futura). Nenhuma lógica de negócio,
nenhuma tela funcional, nenhum acesso real ao IndexedDB e nenhuma
configuração completa de PWA (cache/offline) foi implementada ainda —
isso será feito nas etapas seguintes, conforme a ordem combinada.

## Tratamento de erros (Etapa 13)

Camada transversal, que não se encaixa perfeitamente em nenhuma das
camadas acima: `js/utils/errorlog.js` guarda um log dos últimos erros
no `localStorage` — deliberadamente fora do IndexedDB, para continuar
funcionando mesmo se o problema for o próprio IndexedDB. Dois pontos
diferentes alimentam esse log automaticamente, sem que quem escreve
uma tela nova precise se preocupar com isso:

- `js/db/database.js`: qualquer erro nas operações genéricas
  (`dbAdd`, `dbPut`, etc.) é registrado antes de ser relançado.
- `js/app.js`: os listeners globais de `error` e `unhandledrejection`
  capturam qualquer erro que escape de um `try/catch` específico.

A tela de Diagnóstico (`js/pages/settings.js`) só lê esse log — não é
ela quem decide o que é ou não registrado.

## Status final

As 15 etapas planejadas foram concluídas. Veja `docs/changelog.md`
para o histórico detalhado de cada uma, incluindo o que ficou de fora
de propósito (documentado em "Limitações conhecidas" no `README.md`).
